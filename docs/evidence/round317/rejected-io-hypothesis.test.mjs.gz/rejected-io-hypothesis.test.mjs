import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreeFrameClient} from '../../src/host/free-frame-client.mjs';
const drain=async()=>{for(let i=0;i<60;i++)await Promise.resolve();};
const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
function fixture(role='workspace',{observerMode='normal'}={}){
 const nativePending=[];let time=1000,id=0,navOptions,views=0;const timers=new Map(),listeners=new Set(),messageListeners=new Set(),historicalMessages=[],parentMessages=[],calls=[],pages=[],states=[],presented=[],restoredViews=[];let factories=0,stops=0,invalidations=0,recoveryOptions,recoveryOpens=0,recoveryStops=0,recoveryInvalidations=0,backupOptions,backupOpens=0,backupStops=0,backupInvalidations=0,snippetOptions,snippetOpens=0,snippetStops=0,snippetInvalidations=0;
 const element=()=>({children:[],setAttribute(){},append(n){n.parent=this;this.children.push(n);},replaceChildren(){this.children=[];},remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);}});
 const body=element(),privateRoot=element();body.append(privateRoot);
 const events=new Map();const document={visibilityState:'visible',addEventListener:(k,f)=>events.set(k,f),removeEventListener:k=>events.delete(k),body,createElement:element,defaultView:{parent:{postMessage(message,origin){parentMessages.push({message,origin});}}}};
 document.documentElement=element();const observers=[];
 if(observerMode!=='missing')document.defaultView.IntersectionObserver=class{
  constructor(callback){if(observerMode==='constructor-error')throw Error('observer-unavailable');this.callback=callback;this.disconnected=false;observers.push(this);}
  observe(target){this.target=target;if(observerMode==='observe-error')throw Error('observe-unavailable');if(observerMode==='initial-hidden')this.callback([{target,time:0,isIntersecting:false}],this);}
  disconnect(){this.disconnected=true;}
 };
 const intersection=(isIntersecting,stamp=1,{observer=observers.at(-1),target=document.documentElement}={})=>{assert(observer,'intersection observer must be installed');observer.callback([{target,time:stamp,isIntersecting}],observer);};
 const grant=()=>({id:'grant',mountId:'mount',parentDocumentId:'parent',uiDocumentId:'ui',scopeGrantId:'scope',role,expiresAt:new Date(time+20000).toISOString()});
 const page=()=>({protocol:'vaiwl-free-frame/1',role,scope:'A',completeSnapshot:false,groups:{items:[]},entries:{noProject:{items:[]},unknown:{items:[]}},selection:null});
 let view=async()=>({ok:true,state:'ready',page:page(),navigation:[]});
 const runtime={connect:()=>({onMessage:{addListener:fn=>{messageListeners.add(fn);historicalMessages.push(fn);},removeListener:fn=>messageListeners.delete(fn)},onDisconnect:{addListener:f=>listeners.add(f),removeListener:f=>listeners.delete(f)},disconnect(){}}),sendMessage:async m=>{calls.push(m);if(m.type==='HOST_UI_VIEW'){views++;return view(m);}return {ok:true,grant:grant()};}};
 const client=createFreeFrameClient({document,privateRoot,runtime,role,parentOrigin:'https://chatgpt.com',onState:s=>states.push(s),now:()=>time,elapsedNow:()=>time,makeNonce:()=> 'nonce',schedule:(fn,ms)=>{const key=++id;timers.set(key,{fn,at:time+ms});return key;},cancel:key=>timers.delete(key),snippetsFactory:options=>{snippetOptions=options;return {open(){snippetOpens++;},stop(){snippetStops++;},invalidate(){snippetInvalidations++;}};},backupFactory:options=>{backupOptions=options;return {open(){backupOpens++;},stop(){backupStops++;},invalidate(){backupInvalidations++;}};},recoveryFactory:options=>{recoveryOptions=options;return {open(){recoveryOpens++;},stop(){recoveryStops++;},invalidate(){recoveryInvalidations++;}};},navigationFactory:options=>{factories++;navOptions=options;return {setNativeNavigationPending:value=>nativePending.push(value),restoreFrameView:value=>restoredViews.push(value),invalidate(){invalidations++;},present:intent=>presented.push(intent),updateFrameProjection:p=>pages.push(p),stop:()=>{stops++;}};}});
 return {document,observers,intersection,visibility(value){document.visibilityState=value;events.get('visibilitychange')?.();},nativePending,parentMessages,restoredViews,jump(ms){time+=ms;},runtime,grant,presented,messageListeners,historicalMessages,emit:m=>{for(const fn of [...messageListeners])fn(m);},client,calls,pages,states,body,privateRoot,page,setView:fn=>{view=fn;},get snippets(){return snippetOptions;},get snippetOpens(){return snippetOpens;},get snippetStops(){return snippetStops;},get snippetInvalidations(){return snippetInvalidations;},get backup(){return backupOptions;},get backupOpens(){return backupOpens;},get backupStops(){return backupStops;},get backupInvalidations(){return backupInvalidations;},get recovery(){return recoveryOptions;},get recoveryOpens(){return recoveryOpens;},get recoveryStops(){return recoveryStops;},get recoveryInvalidations(){return recoveryInvalidations;},get invalidations(){return invalidations;},get nav(){return navOptions;},get factories(){return factories;},get stops(){return stops;},get views(){return views;},disconnect:()=>{for(const fn of [...listeners])fn();},async advance(ms){time+=ms;for(const [key,t]of [...timers])if(t.at<=time&&timers.has(key)){timers.delete(key);t.fn();}await drain();}};
}

const hint=f=>f.emit({type:'VAIWL_UI_DATA_CHANGED'});
const ready=f=>({ok:true,state:'ready',page:f.page(),navigation:[]});
for(const mode of ['normal','missing','constructor-error','observe-error'])test('intersection unknown or unavailable remains active: '+mode,async t=>{
 const f=fixture('workspace',{observerMode:mode});t.after(()=>f.client.stop());await f.client.start();await drain();assert.equal(f.views,1);const before=f.views;hint(f);await drain();assert.equal(f.views,before+1);
});
for(const role of ['workspace','sidebar'])test(role+': nonintersection coalesces ordinary hints and reentry reads once without calibration',async t=>{
 const f=fixture(role);t.after(()=>f.client.stop());await f.client.start();await drain();f.intersection(false,1);const before=f.views,calibrations=f.calls.filter(m=>m.type==='HOST_UI_CALIBRATION_ENTRY').length;
 for(let i=0;i<20;i++)hint(f);await drain();assert.equal(f.views,before);
 const held=deferred();f.setView(()=>held.promise);f.intersection(true,2);await drain();assert.equal(f.views,before+1);f.intersection(true,3);await drain();assert.equal(f.views,before+1);held.resolve(ready(f));await drain();assert.equal(f.views,before+1);assert.equal(f.calls.filter(m=>m.type==='HOST_UI_CALIBRATION_ENTRY').length,calibrations);
});
for(const role of ['workspace','sidebar'])test(role+': inflight completion while nonintersecting never chains a dirty read',async t=>{
 const f=fixture(role);t.after(()=>f.client.stop());await f.client.start();await drain();const held=deferred();f.setView(()=>held.promise);hint(f);await drain();const views=f.views;f.intersection(false,1);hint(f);held.resolve(ready(f));await drain();assert.equal(f.views,views);f.setView(async()=>ready(f));f.intersection(true,2);await drain();assert.equal(f.views,views+1);
});
test('intersection becoming true cannot override hidden document visibility',async t=>{
 const f=fixture();t.after(()=>f.client.stop());await f.client.start();await drain();f.intersection(false,1);f.visibility('hidden');hint(f);const before=f.views;f.intersection(true,2);await drain();assert.equal(f.views,before);f.visibility('visible');await drain();assert.equal(f.views,before+1);
});
test('explicit projection remains immediate while the frame is nonintersecting',async t=>{
 const f=fixture();t.after(()=>f.client.stop());await f.client.start();await drain();f.intersection(false,1);const before=f.views;const result=await f.nav.onProjectionRequest({segment:1,offset:0,limit:8});await drain();assert.equal(f.views,before+1);assert.equal(result.protocol,'vaiwl-free-frame/1');
});
for(const panel of ['backup','recovery','snippets'])test('nonintersection does not delay '+panel+' invalidation',async t=>{
 const f=fixture();t.after(()=>f.client.stop());await f.client.start();await drain();f.nav[{backup:'onBackupRequest',recovery:'onRecoveryRequest',snippets:'onSnippetsRequest'}[panel]]();await drain();f.intersection(false,1);const before=f.views;hint(f);hint(f);await drain();assert.equal(f[{backup:'backupInvalidations',recovery:'recoveryInvalidations',snippets:'snippetInvalidations'}[panel]],2);assert.equal(f.views,before);
});
test('initial bootstrap is authorized even when first observer delivery is nonintersecting',async t=>{
 const f=fixture('workspace',{observerMode:'initial-hidden'});t.after(()=>f.client.stop());await f.client.start();await drain();assert.equal(f.views,1);assert.equal(f.pages.length,1);
});
for(const terminal of ['disconnect','stop','expiry'])test('late intersecting callback cannot revive work after '+terminal,async t=>{
 const f=fixture();t.after(()=>f.client.stop());await f.client.start();await drain();f.intersection(false,1);hint(f);if(terminal==='disconnect')f.disconnect();if(terminal==='stop')f.client.stop();if(terminal==='expiry')f.jump(20001);const views=f.views;f.intersection(true,2);hint(f);await drain();assert.equal(f.views,views);if(terminal!=='expiry')assert.equal(f.observers[0].disconnected,true);
});
test('old observer is fenced after clear and new grant even if its time is newer',async t=>{
 const f=fixture();t.after(()=>f.client.stop());await f.client.start();await drain();const old=f.observers[0];f.intersection(false,1);f.client.stop();await f.client.start();await drain();assert.notEqual(f.observers.at(-1),old);f.intersection(false,2);hint(f);const views=f.views;f.intersection(true,1000,{observer:old});await drain();assert.equal(f.views,views);f.intersection(true,3);await drain();assert.equal(f.views,views+1);
});
test('wrong target and older observation times cannot override newest nonintersection',async t=>{
 const f=fixture();t.after(()=>f.client.stop());await f.client.start();await drain();f.intersection(false,10);hint(f);const views=f.views;f.intersection(true,11,{target:{}});f.intersection(true,9);await drain();assert.equal(f.views,views);f.intersection(true,12);await drain();assert.equal(f.views,views+1);
});
