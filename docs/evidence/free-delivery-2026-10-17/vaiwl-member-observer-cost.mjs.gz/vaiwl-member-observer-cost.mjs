import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs');
const {createServer}=await import(root+'simulator/server.mjs');
const hash=s=>createHash('sha256').update(s).digest('hex');
const paths=(await readdir(root+'src',{recursive:true})).filter(p=>p.endsWith('.mjs')).map(p=>'src/'+p);
const hashes=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await readFile(root+p))])));
const sourceHashes=await hashes(),server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
const report={evidence:'DIAGNOSTIC_REAL_IDB_MEMBER_OBSERVER_COST_AB',hostAcceptance:'NOT_ESTABLISHED',sourceHashes,observerScope:'Known existing synthetic scope, no first-time scope-discovery cursor; fresh DB connection and NativeRepository every sample; exact tail page; no acceptance assertion from interim samples',rows:[]};
try{
 browser=await chromium.launch({headless:true,executablePath:process.env.FREE_CHROME_EXECUTABLE??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 for(const [round,order] of [[0,['no-observer','observer']],[1,['observer','no-observer']],[2,['no-observer','observer']]])for(const variant of order){
  const context=await browser.newContext();await context.route('**/*',async route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();return route.continue();});
  try{const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');let evaluationTimer;const result=await Promise.race([page.evaluate(async(withObserver)=>{
   const {ScopeRepository}=await import('/src/b1/scope-repository.mjs'),{NativeRepository}=await import('/src/data/native-repository.mjs'),{WorkspaceRepository}=await import('/src/data/repository.mjs'),{scopeOf}=await import('/simulator/data.mjs'),{emptyNativeFacts}=await import('/src/data/native-facts.mjs'),{digest}=await import('/src/data/hash.mjs');
   const scope=scopeOf('A'),scopeKey=emptyNativeFacts(scope).scopeKey,base=new ScopeRepository({indexedDB,databaseName:'shared-cost-diagnostic'}),shared=new WorkspaceRepository({baseRepository:base,evidenceGate:()=> 'synthetic'}),native=new NativeRepository({baseRepository:base,workspaceRepository:shared,hostObservationGate:(_s,r)=>({channel:'host-dom',sourceId:'fixture',generation:'one',guard:()=>true,admission:{profileId:'profile_one',profileVersion:1,evidenceClass:'surface',semanticFingerprint:digest(r.batch),acceptedAt:'2026-10-13T00:00:00Z'}}),clock:()=> '2026-10-13T00:00:00Z'});
   const request=(n,rev)=>{const refs=Array.from({length:50},(_,i)=>({id:'60000000-0000-4000-8000-'+((n-1)*50+i).toString(16).padStart(12,'0'),nativeTitle:'原生压力聊天 '+String((n-1)*50+i).padStart(6,'0')+' · 长中文标题与 English mixed 内容用于尾部原名检索及实际可达验证，不代表真实聊天。',nativeUrl:'https://fixture.test/c/'+((n-1)*50+i),availability:'available'}));return {operationId:'write_'+n,expectedRevision:rev,batch:{scopeKey,sourceRevision:n,observedAt:'2026-10-13T00:00:00Z',validUntil:'2026-10-14T00:00:00Z',projects:n===1?[{id:'P',nativeName:'Project',nativeUrl:'https://fixture.test/project/P',availability:'available'}]:[],refs,membership:refs.map(r=>({id:r.id,state:'PROJECT',projectId:'P'})),inventory:{projects:'partial',conversations:'partial',cursor:null}}};};
   const observer={samples:0,transactions:0,elapsedMs:0,transactionMs:0,openMs:0,lastRevision:null,lastTotal:null,tailSeen:0},databaseName='shared-cost-diagnostic',tail='60000000-0000-4000-8000-00000000270f';
   let stopped=false,timer=null,flight=null,observerError=null;
   async function sample(){let connection;const began=performance.now();try{
    const opening=performance.now(),info=(await indexedDB.databases()).find(d=>d.name===databaseName);if(!info)throw Error('observer-existing-database-missing');
    connection=await new Promise((resolve,reject)=>{const q=indexedDB.open(info.name,info.version);q.onupgradeneeded=()=>{q.transaction.abort();reject(Error('observer-refuses-upgrade'));};q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});observer.openMs+=performance.now()-opening;
    const readonlyDB={transaction(names,mode='readonly'){if(mode!=='readonly')throw Error('observer-refuses-write');const at=performance.now(),tx=connection.transaction(names,'readonly');observer.transactions++;tx.addEventListener('complete',()=>observer.transactionMs+=performance.now()-at);tx.addEventListener('abort',()=>observer.transactionMs+=performance.now()-at);return tx;}};
    const fresh=new NativeRepository({baseRepository:{scopeOrThrow:value=>base.scopeOrThrow(value),open:async()=>readonlyDB}});
    const page=await fresh.page(scope,{ids:{projects:[],refs:[tail]},limit:1});
    if(page.selectedRefs.length!==1||page.selectedRefs[0]!==tail||page.selectedProjects.length!==0||!Number.isSafeInteger(page.revision))throw Error('invalid-observer-page');
    const ref=page.facts.refs[tail],membership=page.facts.membership[tail];
    if(ref&&membership&&membership.state!=='UNKNOWN'){if(ref.id!==tail||membership.id!==tail||membership.state!=='PROJECT'||membership.projectId!=='P'||page.facts.projects.P?.id!=='P')throw Error('wrong-observer-membership');observer.tailSeen++;}
    observer.samples++;observer.lastRevision=page.revision;observer.lastTotal=page.total;
   }finally{connection?.close();observer.elapsedMs+=performance.now()-began;}}
   function tick(){if(stopped)return;flight=sample().catch(error=>{observerError=error;stopped=true;}).finally(()=>{flight=null;if(!stopped)timer=setTimeout(tick,100);});}
   async function stopObserver(){stopped=true;clearTimeout(timer);timer=null;await flight;}
   try{
    const seed=await native.apply(scope,request(1,0));if(!seed.ok)throw Error(JSON.stringify(seed));const migrated=await native.migrateVersionIndex(scope,{operationId:'migration',expectedRevision:1});if(!migrated.ok)throw Error(JSON.stringify(migrated));const times=[],start=performance.now();if(withObserver)tick();
    for(let n=2;n<=200;n++){if(observerError)throw observerError;const at=performance.now(),r=await native.apply(scope,request(n,n));if(!r.ok)throw Error(JSON.stringify(r));times.push(performance.now()-at);}
    const elapsedMs=performance.now()-start;await stopObserver();if(observerError)throw observerError;
    const facts=await native.read(scope),ids=Object.keys(facts.refs),sharedFacts=(await shared.read(scope)).state;
    if(ids.length!==10000||ids.some(id=>facts.membership[id]?.projectId!=='P')||Object.keys(sharedFacts.refs).length!==10000)throw Error('incomplete-native-or-shared-facts');
    return {elapsedMs,batches:199,ids:ids.length,revision:facts.revision,factsHash:digest(facts),sharedFactsHash:digest(sharedFacts),batchMs:times,observer};
   }finally{await stopObserver();base.close();}
  },variant==='observer'),new Promise((_,reject)=>{evaluationTimer=setTimeout(()=>reject(Error('diagnostic-evaluation-deadline')),60000);})]).finally(()=>clearTimeout(evaluationTimer));report.rows.push({round,variant,...result});console.log(JSON.stringify({round,variant,elapsedMs:result.elapsedMs,ids:result.ids}));}finally{await context.close();}
 }
 assert.equal(new Set(report.rows.map(r=>r.factsHash)).size,1);assert.equal(new Set(report.rows.map(r=>r.sharedFactsHash)).size,1);report.status='MEASURED_NOT_HOST_ACCEPTANCE';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{
 for(const [stage,close] of [['browser',()=>browser?.close()],['server',()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))],['source-integrity',async()=>assert.deepEqual(await hashes(),sourceHashes)]])try{await close();}catch(error){(report.cleanupErrors??=[]).push({stage,error:String(error)});report.status='FAIL';process.exitCode=1;}
 await writeFile('/private/tmp/vaiwl-member-observer-cost.json',JSON.stringify(report,null,2)+'\n');
}
