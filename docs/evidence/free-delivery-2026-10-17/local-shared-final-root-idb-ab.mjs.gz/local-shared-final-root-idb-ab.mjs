import {execFileSync} from 'node:child_process';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs'),{createServer}=await import(root+'simulator/server.mjs');
const hash=v=>createHash('sha256').update(v).digest('hex'),files=['src/data/shared-ref-directory.mjs','src/data/shared-directory-writer.mjs'];
const baseline=Object.fromEntries(files.map(p=>[p,execFileSync('git',['show','af58a31:'+p],{cwd:root,encoding:'utf8'})]));
const candidate=Object.fromEntries(await Promise.all(files.map(async p=>[p,await readFile(root+p,'utf8')])));
assert(files.some(p=>candidate[p]!==baseline[p]));const paths=(await readdir(root+'src',{recursive:true})).filter(p=>p.endsWith('.mjs')).map(p=>'src/'+p);
const hashes=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await readFile(root+p))]))),sourceHashes=await hashes();
const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
const report={evidence:'DIAGNOSTIC_REAL_IDB_SHARED_FINAL_ROOT_AB_NO_INSTRUMENTATION',acceptance:'NOT_ESTABLISHED',baseline:'af58a31',sourceHashes,moduleHashes:Object.fromEntries(files.map(p=>[p,{baseline:hash(baseline[p]),candidate:hash(candidate[p])}])),rows:[]};
try{
 const executablePath=process.env.FREE_CHROME_EXECUTABLE;if(!executablePath)throw Error('explicit-browser-required');report.executablePath=executablePath;
 browser=await chromium.launch({headless:true,executablePath});report.browserVersion=browser.version();
 for(const [round,order]of [[0,['baseline','candidate']],[1,['candidate','baseline']],[2,['baseline','candidate']]])for(const variant of order){
  const context=await browser.newContext();await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();const p=u.pathname.slice(1);return files.includes(p)?route.fulfill({status:200,contentType:'text/javascript',body:(variant==='baseline'?baseline:candidate)[p]}):route.continue();});
  try{const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');let timer;const result=await Promise.race([page.evaluate(async()=>{
  const [{ScopeRepository},{WorkspaceRepository},{emptyState},{digest}]=await Promise.all(['/src/b1/scope-repository.mjs','/src/data/repository.mjs','/src/data/state.mjs','/src/data/hash.mjs'].map(p=>import(p)));
  const scope={verified:true,provider:'chatgpt',accountId:'fixture',organizationId:'personal'},base=new ScopeRepository({indexedDB,databaseName:'shared-piece-count'}),repo=new WorkspaceRepository({baseRepository:base,evidenceGate:()=> 'synthetic'}),state=emptyState(scope);
  const id=i=>'60000000-0000-4000-8000-'+i.toString(16).padStart(12,'0'),ref=i=>({id:id(i),nativeUrl:'https://fixture.test/c/'+id(i),nativeTitle:'Synthetic title '+i,projectId:'P',available:true});state.revision=1;state.channel='synthetic';for(let i=0;i<3200;i++)state.refs[id(i)]=ref(i);
  try{
   if(!(await repo.initializePartitioned(scope,state)).ok)throw Error('seed-failed');if(!(await repo.migrateSharedDirectory(scope,{operationId:'count_migration',expectedRevision:1})).ok)throw Error('migration-failed');
   const db=await base.open(),normalized=base.scopeOrThrow(scope);let result;
   // Deterministic benchmark-only legal metadata seed, identical in both arms.
   await new Promise((resolve,reject)=>{const tx=db.transaction('b23_states','readwrite'),store=tx.objectStore('b23_states'),q=store.get(normalized.key);q.onsuccess=()=>{const payload=q.result.payload;payload.revision=65;payload.changes=Array.from({length:64},(_,i)=>({revision:i+1,refs:Array.from({length:50},(_,j)=>id(i*50+j))}));store.put({key:normalized.key,payload,checksum:digest(payload)});};tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});
   const started=performance.now();await new Promise((resolve,reject)=>{const tx=db.transaction(['b23_states','b23_checkpoints','b23_operations','refs'],'readwrite');let error;repo.registerNativeReferences(tx,normalized,Array.from({length:50},(_,i)=>({...ref(3200+i),availability:'available'})),'count_register',()=>{},v=>{result=v;},e=>{error=e;tx.abort();},{preferDirectory:true,migrateLegacy:true});tx.oncomplete=resolve;tx.onabort=()=>reject(error??tx.error);});const registrationMs=performance.now()-started;
   const facts=(await repo.read(scope)).state;if(Object.keys(facts.refs).length!==3250||result?.added!==50)throw Error('incomplete-registration');
   return {registrationMs,factsDigest:digest(facts),added:result.added,refs:Object.keys(facts.refs).length,changeRows:64,changeRefs:3200};
  }finally{base.close();}
  }),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('diagnostic-deadline')),60000);})]).finally(()=>clearTimeout(timer));report.rows.push({round,variant,...result});console.log(JSON.stringify({round,variant,registrationMs:result.registrationMs}));}finally{await context.close();}
 }
 assert.equal(new Set(report.rows.map(r=>r.factsDigest)).size,1);for(const variant of ['baseline','candidate']){const values=report.rows.filter(r=>r.variant===variant).map(r=>r.registrationMs).sort((a,b)=>a-b);report[variant+'MedianMs']=values[1];}report.status='MEASURED_NOT_HOST_ACCEPTANCE';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{
 for(const [stage,close]of [['browser',()=>browser?.close()],['server',()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))],['source-integrity',async()=>assert.deepEqual(await hashes(),sourceHashes)]])try{await close();}catch(error){(report.cleanupErrors??=[]).push({stage,error:String(error)});report.status='FAIL';process.exitCode=1;}
 await writeFile('/private/tmp/shared-final-root-idb-ab.json',JSON.stringify(report,null,2)+'\n');
}
