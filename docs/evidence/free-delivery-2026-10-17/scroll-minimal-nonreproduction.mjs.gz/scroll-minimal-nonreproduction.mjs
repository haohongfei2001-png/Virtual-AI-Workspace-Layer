import http from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {chromium} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/b1/tooling/node_modules/playwright/index.mjs';
const server=http.createServer(async(req,res)=>{try{let p=new URL(req.url,'http://127.0.0.1').pathname;if(p==='/'){res.setHeader('content-type','text/html');res.end('<!doctype html><head><style>html,body{height:100%;margin:0;overflow:hidden}main{height:100%;min-height:0;display:flex;flex-direction:column;overflow:auto}main>div{min-width:0;min-height:0;box-sizing:border-box}#mount{flex:1 1 0;overflow:auto}</style></head><body><main><div id="mount"></div></main>');return;}if(!/^\/src\/(navigation|data|b1|host)\/[a-z0-9-]+\.mjs$/.test(p))throw Error();res.setHeader('content-type','text/javascript');res.end(await readFile(resolve('.'+p)));}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
const results=[];
try{
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 const context=await browser.newContext(),origin='http://127.0.0.1:'+server.address().port;
 await context.route('**/*',r=>new URL(r.request().url()).origin===origin?r.continue():r.abort());
 const page=await context.newPage();await page.setViewportSize({width:1100,height:471});
 for(const anchor of ['auto','none'])for(const maxSegment of [0,2]){
 await page.goto(origin);
 await page.evaluate(async({anchor,maxSegment})=>{
  const {createNavigation}=await import('/src/navigation/navigation.mjs');
  const p=(items=[],limit=5)=>({items,total:items.length,offset:0,limit,hasMore:false});
  const row=id=>({id,scope:'A',nativeTitle:id,displayTitle:id,nativeUrl:'https://chatgpt.com/c/'+id,available:true,membership:'UNKNOWN',projectId:null,segment:null});
  const groups=Array.from({length:8},(_,i)=>({id:'P'+i,nativeName:'Project '+i,name:'Project '+i,segment:0,lists:{current:p(),old:p(),unknown:p(Array.from({length:i===0?17:0},(_,j)=>row('P'+i+'_'+j)),17)}}));
  globalThis.dto={protocol:'vaiwl-free-frame/1',role:'workspace',scope:'A',completeSnapshot:false,segment:0,viewSession:{H:30,T:20000,Z:'UTC',policyRevision:0},navigation:{hasNewer:false,hasOlder:maxSegment>0,maxSegment},groups:{...p(groups,8)},entries:{noProject:{...p(),inventoryTotal:0},unknown:{...p(Array.from({length:17},(_,i)=>row('U'+i)),17),inventoryTotal:17}},selection:null};
  globalThis.nav=createNavigation({document,surface:{role:'workspace',root:document.querySelector('#mount')},adapter:{currentURL:()=>'',isCurrent:()=>false,status(){}},onProjectionRequest:q=>q.search?{...dto,groups:{...dto.groups,items:dto.groups.items.map(g=>({...g,lists:{...g.lists,unknown:p(g.lists.unknown.items.slice(0,5))}}))},entries:{...dto.entries,unknown:{...p(dto.entries.unknown.items.slice(0,5)),inventoryTotal:17}},search:{...q.search,...p([row('result')],24)}}:new Promise(r=>setTimeout(()=>r(dto),30))});
  nav.updateFrameProjection(dto);
  const style=document.createElement('style');style.textContent='.workspace{overflow-anchor:'+anchor+'}';nav.roots().workspace.shadow.append(style);
  globalThis.measure=()=>({top:nav.roots().workspace.scroller.scrollTop,view:nav.view().scroll,total:nav.roots().workspace.scroller.scrollHeight,height:nav.roots().workspace.scroller.clientHeight,focus:nav.roots().workspace.shadow.activeElement?.getAttribute('aria-label')});
  nav.roots().workspace.scroller.scrollTop=150;
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
 },{anchor,maxSegment});
 const before=await page.evaluate(()=>measure());
 await page.evaluate(()=>nav.present({kind:'search-known'}));
 await page.getByRole('button',{name:'关闭派生查找',exact:true}).click();
 const after=await page.evaluate(async()=>{const sync=measure();nav.updateFrameProjection(dto);const update=measure();await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return {sync,update,late:measure()};});
 results.push({anchor,maxSegment,before,after});
 }
}finally{await browser?.close();await new Promise(r=>server.close(r));await writeFile('/private/tmp/vaiwl-min-scroll.json',JSON.stringify(results,null,2));}
console.log(JSON.stringify(results));
