import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs');
const {createServer}=await import(root+'simulator/server.mjs');
const hash=s=>createHash('sha256').update(s).digest('hex');
const paths=(await readdir(root+'src',{recursive:true})).filter(p=>p.endsWith('.mjs')).map(p=>'src/'+p);
const hashes=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await readFile(root+p))])));
const baseline=await readFile(root+'src/data/native-repository.mjs','utf8'),candidate=await readFile('/private/tmp/free-native-reader-candidate.mjs','utf8');
assert.equal(baseline,execFileSync('git',['show','650ff2d:src/data/native-repository.mjs'],{cwd:root,encoding:'utf8'}),'baseline must match 650ff2d');
assert.notEqual(baseline,candidate,'candidate must differ');
const sourceHashes=await hashes(),server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
const report={evidence:'DIAGNOSTIC_REAL_IDB_NATIVE_READER_OWNER_PAGE_APPLY_AB',hostAcceptance:'NOT_ESTABLISHED',sourceHashes,baselineHash:hash(baseline),candidateHash:hash(candidate),scope:'199 sequential targeted page + native/shared apply pairs, 50 seed + 199x50 new refs; no observer; source module replacement only',rows:[]};
try{
 browser=await chromium.launch({headless:true,executablePath:process.env.FREE_CHROME_EXECUTABLE??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 for(const [round,order] of [[0,['baseline','candidate']],[1,['candidate','baseline']],[2,['baseline','candidate']]])for(const variant of order){
  const context=await browser.newContext();await context.route('**/*',async route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();if(u.pathname==='/src/data/native-repository.mjs')return route.fulfill({status:200,contentType:'text/javascript',body:variant==='candidate'?candidate:baseline});return route.continue();});
  try{const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');let evaluationTimer;const result=await Promise.race([page.evaluate(async()=>{
   const {ScopeRepository}=await import('/src/b1/scope-repository.mjs'),{NativeRepository}=await import('/src/data/native-repository.mjs'),{WorkspaceRepository}=await import('/src/data/repository.mjs'),{scopeOf}=await import('/simulator/data.mjs'),{emptyNativeFacts}=await import('/src/data/native-facts.mjs'),{digest}=await import('/src/data/hash.mjs');
   const scope=scopeOf('A'),scopeKey=emptyNativeFacts(scope).scopeKey,base=new ScopeRepository({indexedDB,databaseName:'shared-cost-diagnostic'}),shared=new WorkspaceRepository({baseRepository:base,evidenceGate:()=> 'synthetic'}),native=new NativeRepository({baseRepository:base,workspaceRepository:shared,hostObservationGate:(_s,r)=>({channel:'host-dom',sourceId:'fixture',generation:'one',guard:()=>true,admission:{profileId:'profile_one',profileVersion:1,evidenceClass:'surface',semanticFingerprint:digest(r.batch),acceptedAt:'2026-10-13T00:00:00Z'}}),clock:()=> '2026-10-13T00:00:00Z'});
   const request=(n,rev)=>{const refs=Array.from({length:50},(_,i)=>({id:'60000000-0000-4000-8000-'+((n-1)*50+i).toString(16).padStart(12,'0'),nativeTitle:'原生压力聊天 '+String((n-1)*50+i).padStart(6,'0')+' · 长中文标题与 English mixed 内容用于尾部原名检索及实际可达验证，不代表真实聊天。',nativeUrl:'https://fixture.test/c/'+((n-1)*50+i),availability:'available'}));return {operationId:'write_'+n,expectedRevision:rev,batch:{scopeKey,sourceRevision:n,observedAt:'2026-10-13T00:00:00Z',validUntil:'2026-10-14T00:00:00Z',projects:n===1?[{id:'P',nativeName:'Project',nativeUrl:'https://fixture.test/project/P',availability:'available'}]:[],refs,membership:refs.map(r=>({id:r.id,state:'PROJECT',projectId:'P'})),inventory:{projects:'partial',conversations:'partial',cursor:null}}};};
   try{
    const seed=await native.apply(scope,request(1,0));if(!seed.ok)throw Error(JSON.stringify(seed));const migrated=await native.migrateVersionIndex(scope,{operationId:'migration',expectedRevision:1});if(!migrated.ok)throw Error(JSON.stringify(migrated));const times=[],pageMs=[],applyMs=[],start=performance.now();
    for(let n=2;n<=200;n++){
     const req=request(n,n),refs=req.batch.refs.map(r=>r.id),at=performance.now();
     const observed=await native.page(scope,{ids:{projects:[],refs},limit:50});
     if(observed.revision!==n||observed.selectedRefs.length!==50||observed.selectedRefs.some((id,i)=>id!==refs[i])||Object.keys(observed.facts.refs).length!==0)throw Error('invalid-targeted-pre-apply-page');
     const paged=performance.now();pageMs.push(paged-at);
     const result=await native.apply(scope,req);if(!result.ok)throw Error(JSON.stringify(result));
     applyMs.push(performance.now()-paged);times.push(performance.now()-at);
    }
    const elapsedMs=performance.now()-start;
    const facts=await native.read(scope),ids=Object.keys(facts.refs),sharedFacts=(await shared.read(scope)).state;
    if(ids.length!==10000||ids.some(id=>facts.membership[id]?.projectId!=='P')||Object.keys(sharedFacts.refs).length!==10000)throw Error('incomplete-native-or-shared-facts');
    return {elapsedMs,batches:199,ids:ids.length,revision:facts.revision,factsHash:digest(facts),sharedFactsHash:digest(sharedFacts),batchMs:times,pageMs,applyMs};
   }finally{base.close();}
  }),new Promise((_,reject)=>{evaluationTimer=setTimeout(()=>reject(Error('diagnostic-evaluation-deadline')),60000);})]).finally(()=>clearTimeout(evaluationTimer));report.rows.push({round,variant,...result});console.log(JSON.stringify({round,variant,elapsedMs:result.elapsedMs,ids:result.ids}));}finally{await context.close();}
 }
 assert.equal(new Set(report.rows.map(r=>r.factsHash)).size,1);assert.equal(new Set(report.rows.map(r=>r.sharedFactsHash)).size,1);report.status='MEASURED_NOT_HOST_ACCEPTANCE';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{
 for(const [stage,close] of [['browser',()=>browser?.close()],['server',()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))],['source-integrity',async()=>{assert.deepEqual(await hashes(),sourceHashes);assert.equal(hash(await readFile('/private/tmp/free-native-reader-candidate.mjs')),hash(candidate));}]])try{await close();}catch(error){(report.cleanupErrors??=[]).push({stage,error:String(error)});report.status='FAIL';process.exitCode=1;}
 await writeFile('/private/tmp/free-native-reader-idb-ab.json',JSON.stringify(report,null,2)+'\n');
}
