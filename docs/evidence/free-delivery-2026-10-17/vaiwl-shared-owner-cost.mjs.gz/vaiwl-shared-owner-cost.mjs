import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs');
const {createServer}=await import(root+'simulator/server.mjs');
const original=await readFile(root+'src/data/native-repository.mjs','utf8');
const candidate=original;
const hash=s=>createHash('sha256').update(s).digest('hex');const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
const report={evidence:'DIAGNOSTIC_REAL_IDB_SHARED_OWNER_COST',hostAcceptance:'NOT_ESTABLISHED',baselineHash:hash(original),candidateHash:hash(candidate),changes:'native owner versus native plus shared directory; no optimization or production authority claim',rows:[]};
try{
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 for(const [round,order] of [[0,['baseline','candidate']],[1,['candidate','baseline']],[2,['baseline','candidate']]])for(const variant of order){
  const context=await browser.newContext();await context.route('**/*',async route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();if(u.pathname==='/src/data/native-repository.mjs')return route.fulfill({status:200,contentType:'text/javascript',body:variant==='candidate'?candidate:original});return route.continue();});
  try{const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');const result=await page.evaluate(async(useShared)=>{
   const {ScopeRepository}=await import('/src/b1/scope-repository.mjs'),{NativeRepository}=await import('/src/data/native-repository.mjs'),{WorkspaceRepository}=await import('/src/data/repository.mjs'),{scopeOf}=await import('/simulator/data.mjs'),{emptyNativeFacts}=await import('/src/data/native-facts.mjs'),{digest}=await import('/src/data/hash.mjs');
   const scope=scopeOf('A'),scopeKey=emptyNativeFacts(scope).scopeKey,base=new ScopeRepository({indexedDB,databaseName:'shared-cost-diagnostic'}),shared=useShared?new WorkspaceRepository({baseRepository:base,evidenceGate:()=> 'synthetic'}):null,native=new NativeRepository({baseRepository:base,workspaceRepository:shared,hostObservationGate:(_s,r)=>({channel:'host-dom',sourceId:'fixture',generation:'one',guard:()=>true,admission:{profileId:'profile_one',profileVersion:1,evidenceClass:'surface',semanticFingerprint:digest(r.batch),acceptedAt:'2026-10-13T00:00:00Z'}}),clock:()=> '2026-10-13T00:00:00Z'});
   const request=(n,rev)=>{const refs=Array.from({length:50},(_,i)=>({id:'R'+String((n-1)*50+i).padStart(5,'0'),nativeTitle:'Conversation '+((n-1)*50+i),nativeUrl:'https://fixture.test/c/'+((n-1)*50+i),availability:'available'}));return {operationId:'write_'+n,expectedRevision:rev,batch:{scopeKey,sourceRevision:n,observedAt:'2026-10-13T00:00:00Z',validUntil:'2026-10-14T00:00:00Z',projects:n===1?[{id:'P',nativeName:'Project',nativeUrl:'https://fixture.test/project/P',availability:'available'}]:[],refs,membership:refs.map(r=>({id:r.id,state:'PROJECT',projectId:'P'})),inventory:{projects:'partial',conversations:'partial',cursor:null}}};};
   const seed=await native.apply(scope,request(1,0));if(!seed.ok)throw Error(JSON.stringify(seed));const migrated=await native.migrateVersionIndex(scope,{operationId:'migration',expectedRevision:1});if(!migrated.ok)throw Error(JSON.stringify(migrated));const times=[],start=performance.now();
   for(let n=2;n<=200;n++){const at=performance.now(),r=await native.apply(scope,request(n,n));if(!r.ok)throw Error(JSON.stringify(r));times.push(performance.now()-at);}
   const elapsedMs=performance.now()-start,facts=await native.read(scope),ids=Object.keys(facts.refs);if(ids.length!==10000||ids.some(id=>facts.membership[id]?.projectId!=='P'))throw Error('incomplete-native-facts');base.close();return {elapsedMs,batches:199,ids:ids.length,revision:facts.revision,factsHash:digest(facts),batchMs:times};
  },variant==='candidate');report.rows.push({round,variant,...result});console.log(JSON.stringify({round,variant,elapsedMs:result.elapsedMs,ids:result.ids}));}finally{await context.close();}
 }
 assert.equal(new Set(report.rows.map(r=>r.factsHash)).size,1);report.status='MEASURED_NOT_HOST_ACCEPTANCE';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{await browser?.close();await new Promise(r=>server.close(r));assert.equal(hash(await readFile(root+'src/data/native-repository.mjs','utf8')),hash(original));await writeFile('/private/tmp/free-shared-owner-cost.json',JSON.stringify(report,null,2)+'\n');}
