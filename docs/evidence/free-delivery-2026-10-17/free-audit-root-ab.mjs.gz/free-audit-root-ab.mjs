import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs');
const {createServer}=await import(root+'simulator/server.mjs');
const sources={baseline:await readFile('/private/tmp/free-audit-before.mjs','utf8'),candidate:await readFile(root+'tests/host/fixtures/host-scale-audit.mjs','utf8')};
const scans=Object.fromEntries(Object.entries(sources).map(([name,s])=>[name,s.slice(s.indexOf('   const roots=await'),s.indexOf('\n   check();if(roots.length')).replace('const roots=await','return await')]));
const report={status:'RUNNING',scope:'Root key enumeration only; real IndexedDB, all keys, no Host acceptance',hashes:Object.fromEntries(Object.entries(sources).map(([k,v])=>[k,createHash('sha256').update(v).digest('hex')])),rows:[]};
const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
try{
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking']});const context=await browser.newContext();await context.route('**/*',r=>{const u=new URL(r.request().url());if(u.origin!==origin)return r.abort();const v=u.pathname.slice(1).replace('.mjs','');if(scans[v])return r.fulfill({contentType:'text/javascript',body:'export async function scan(database,track,check,expired){'+scans[v]+'}'});return r.continue();});const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');
 report.rows=await page.evaluate(async scans=>{
  const rows=[];let serial=0;const modules={baseline:await import('/baseline.mjs'),candidate:await import('/candidate.mjs')};
  const run=async(count,scopes,mixed,order,abortAfter=null)=>{
   const db=await new Promise((res,rej)=>{const r=indexedDB.open('audit-'+serial++,1);r.onupgradeneeded=()=>r.result.createObjectStore('native_states');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});
   const keys=Array.from({length:count-scopes},(_,i)=>'!chunk:'+String(i).padStart(8,'0'));if(mixed)keys.splice(0,4,1,new Date(1234),new Uint8Array([1,2]),['array',1]);
   const roots=Array.from({length:scopes},(_,i)=>JSON.stringify([i?'zzzz':'aaa','account','org']));keys.push(...roots);
   await new Promise((res,rej)=>{const tx=db.transaction('native_states','readwrite'),store=tx.objectStore('native_states');for(const key of keys)store.put({payload:{scopeKey:roots.includes(key)?key:'not-root'}},key);tx.oncomplete=res;tx.onabort=()=>rej(tx.error);});
   for(const variant of order){
    let callbacks=0,checks=0,aborts=0;const completions=[];const visited=[];const normalized=k=>k instanceof Date?['date',k.valueOf()]:ArrayBuffer.isView(k)?['binary',...new Uint8Array(k.buffer,k.byteOffset,k.byteLength)]:k instanceof ArrayBuffer?['binary',...new Uint8Array(k)]:[typeof k,k];
    const nativeTx=db.transaction.bind(db);const database={transaction(...args){if(args[1]!=='readonly')throw Error('not-readonly');const tx=nativeTx(...args);completions.push(new Promise(resolve=>{tx.addEventListener('abort',()=>{aborts++;resolve();},{once:true});tx.addEventListener('complete',resolve,{once:true});}));const store=tx.objectStore('native_states');const proxy=new Proxy(store,{get(target,p){if(p==='getAllKeys'||p==='openKeyCursor')return (...args)=>{const req=target[p](...args);req.addEventListener('success',()=>{callbacks++;if(p==='getAllKeys')for(const k of req.result)visited.push(normalized(k));else if(req.result)visited.push(normalized(req.result.key));});return req;};return typeof target[p]==='function'?target[p].bind(target):target[p];}});return new Proxy(tx,{get(target,p){if(p==='objectStore')return ()=>proxy;const v=target[p];return typeof v==='function'?v.bind(target):v;},set(target,p,v){target[p]=v;return true;}});}};
    const check=()=>{if(abortAfter!==null&&++checks>abortAfter)throw Error('audit-deadline');};const at=performance.now();let found,error;
    try{found=await modules[variant].scan(database,x=>x,check,false);}catch(e){error=e.message;}
    await Promise.all(completions);
    const digest=async v=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(v))))).map(n=>n.toString(16).padStart(2,'0')).join('');
    rows.push({count,scopes,mixed,variant,abortAfter,elapsedMs:performance.now()-at,callbacks,visited:visited.length,keysDigest:await digest(visited),roots:found,error,aborts});
   }db.close();
  };
  for(const order of [['baseline','candidate'],['candidate','baseline'],['baseline','candidate']])await run(10000,1,false,order);
  for(const n of [511,512,513,1024])await run(n,2,true,['baseline','candidate']);
  await run(10000,1,false,['baseline','candidate'],520);
  return rows;
 },scans);
 for(let i=0;i<report.rows.length;i+=2){const [a,b]=report.rows.slice(i,i+2);if(a.abortAfter===null){assert.equal(a.keysDigest,b.keysDigest);assert.equal(a.visited,a.count);assert.equal(b.visited,b.count);assert.deepEqual(a.roots,b.roots);assert.equal(a.roots.length,a.scopes);}else{assert.equal(a.error,'audit-deadline');assert.equal(b.error,'audit-deadline');assert.equal(a.aborts,1);assert.equal(b.aborts,1);}}
 report.status='PASS_ROOT_SCAN_ONLY';
}catch(e){report.status='FAIL';report.error=e.stack;process.exitCode=1;}finally{await browser?.close();await new Promise(r=>server.close(r));await writeFile('/private/tmp/free-audit-root-ab.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));}
