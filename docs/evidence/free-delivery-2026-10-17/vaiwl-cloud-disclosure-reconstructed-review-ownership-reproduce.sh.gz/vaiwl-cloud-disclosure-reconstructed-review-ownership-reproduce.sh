#!/usr/bin/env bash
set -euo pipefail
cd "${1:-/workspace/shared/vaiwl-cloud-reconstructed-20261020}"
OUT=/workspace/shared/vaiwl-recovery/reconstructed
{ date -u +%FT%TZ; git rev-parse HEAD; git rev-parse HEAD^{tree}; node --version; } > "$OUT/review-ownership-provenance.txt"
sha256sum src/navigation/navigation.mjs tests/host/frame-projection-renderer.test.mjs tests/navigation/current-dispatch.test.mjs tests/host/working-set-pointer-race.test.mjs tests/host/navigation-queued-background-intent.test.mjs tests/navigation/visible-actions.test.mjs > "$OUT/review-ownership-source-before.sha256"
node --test --test-reporter=tap tests/host/frame-projection-renderer.test.mjs tests/navigation/current-dispatch.test.mjs tests/host/working-set-pointer-race.test.mjs tests/host/navigation-queued-background-intent.test.mjs tests/navigation/visible-actions.test.mjs > "$OUT/review-ownership-targeted-194.tap" 2>&1
node "$OUT/review-ownership.mjs" > "$OUT/review-ownership-results.json"
sha256sum src/navigation/navigation.mjs tests/host/frame-projection-renderer.test.mjs tests/navigation/current-dispatch.test.mjs tests/host/working-set-pointer-race.test.mjs tests/host/navigation-queued-background-intent.test.mjs tests/navigation/visible-actions.test.mjs > "$OUT/review-ownership-source-after.sha256"
cmp "$OUT/review-ownership-source-before.sha256" "$OUT/review-ownership-source-after.sha256"
git diff -- src/navigation/navigation.mjs tests/host/frame-projection-renderer.test.mjs tests/navigation/current-dispatch.test.mjs > "$OUT/review-ownership-reviewed.diff"
