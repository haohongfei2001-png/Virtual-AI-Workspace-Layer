import json,time,re
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright
wanted=json.load(open('/private/tmp/vaiwl-dedicated-target.json'))['targetId']
with sync_playwright() as pw:
 b=pw.chromium.connect_over_cdp('http://127.0.0.1:9333',no_defaults=True,timeout=10000); c=b.contexts[0]; owned=None
 for p in c.pages:
  if urlsplit(p.url).hostname!='chatgpt.com': continue
  s=c.new_cdp_session(p); tid=s.send('Target.getTargetInfo')['targetInfo']['targetId']; s.detach()
  if tid==wanted: owned=p; break
 if owned is None: raise RuntimeError('owned-tab-missing')
 records=[]
 def response(res):
  path=urlsplit(res.url).path
  if path not in ['/backend-api/me','/backend-api/accounts/check/v4-2023-04-27']: return
  try:
   data=res.json(); row={'endpoint':path,'status':res.status,'object':isinstance(data,dict)}
   if path.endswith('/me'):
    row.update({'principalIdPresent':isinstance(data.get('id'),str),'userIdPresent':isinstance(data.get('user',{}),dict) and isinstance(data.get('user',{}).get('id'),str)})
   else:
    accounts=data.get('accounts'); header=res.request.header_value('chatgpt-account-id')
    row.update({'accountsType':type(accounts).__name__,'accountsCount':len(accounts) if isinstance(accounts,(dict,list)) else None,'headerPresent':bool(header),'headerMatchesAccountKey':isinstance(accounts,dict) and header in accounts})
    if isinstance(accounts,dict) and accounts:
     value=next(iter(accounts.values()))
     row['entryFieldNames']=list(value.keys()) if isinstance(value,dict) else []
     row['accountFieldNames']=list(value.get('account',{}).keys()) if isinstance(value,dict) and isinstance(value.get('account'),dict) else []
   records.append(row)
  except Exception as e: records.append({'endpoint':path,'errorType':type(e).__name__})
 owned.on('response',response)
 owned.reload(wait_until='domcontentloaded',timeout=20000)
 owned.wait_for_timeout(5000)
 print(json.dumps({'nativeAccountResponses':records,'surface':owned.evaluate("() => ({editors:document.querySelectorAll('[contenteditable=true],textarea').length,login:!!document.querySelector('[data-testid=login-button]'),projectLinks:[...document.querySelectorAll('a[href]')].filter(e=>/g-p-/.test(e.getAttribute('href'))).length})")},ensure_ascii=False))
