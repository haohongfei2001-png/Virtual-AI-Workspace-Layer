import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs'),{createServer}=await import(root+'simulator/server.mjs');
const path='src/data/verified-record-cache.mjs',source=await readFile(root+path,'utf8'),anchor='function strictJSON(value,onKeys=null,fields=null,counts=null){';assert.equal(source.split(anchor).length,2);
const instrumented=source.replace(anchor,anchor+'globalThis.__sharedCount?.(value);');
const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
const report={evidence:'REAL_CHROME_INDEXEDDB_ACTUAL_REGISTER_NATIVE_REFERENCES_ENCODING_COUNTS',acceptance:'NOT_ESTABLISHED',instrumentation:path,sourceHash:createHash('sha256').update(source).digest('hex')};
try{
 browser=await chromium.launch({headless:true,executablePath:process.env.FREE_CHROME_EXECUTABLE??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});report.browserVersion=browser.version();const context=await browser.newContext();await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();return u.pathname==='/'+path?route.fulfill({status:200,contentType:'text/javascript',body:instrumented}):route.continue();});
 const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');report.result=await page.evaluate(async()=>{
  const identities=new WeakMap(),rows=[];let identity=0,active=false;
  globalThis.__sharedCount=value=>{if(!active||!value?.versions||!Array.isArray(value.ordinals)||typeof value.bucket!=='string')return;if(!identities.has(value))identities.set(value,++identity);rows.push({object:identities.get(value),bucket:value.bucket,revision:value.revision,refs:Object.keys(value.versions).length,caller:new Error().stack.split('\n').slice(3,8).map(s=>s.replaceAll(location.origin,'FIXTURE'))});};
  const [{ScopeRepository},{WorkspaceRepository},{emptyState},{digest}]=await Promise.all(['/src/b1/scope-repository.mjs','/src/data/repository.mjs','/src/data/state.mjs','/src/data/hash.mjs'].map(p=>import(p)));
  const scope={verified:true,provider:'chatgpt',accountId:'fixture',organizationId:'personal'},base=new ScopeRepository({indexedDB,databaseName:'shared-piece-count'}),repo=new WorkspaceRepository({baseRepository:base,evidenceGate:()=> 'synthetic'}),state=emptyState(scope);
  const id=i=>'60000000-0000-4000-8000-'+i.toString(16).padStart(12,'0'),ref=i=>({id:id(i),nativeUrl:'https://fixture.test/c/'+id(i),nativeTitle:'Synthetic title '+i,projectId:'P',available:true});state.revision=1;state.channel='synthetic';for(let i=0;i<3200;i++)state.refs[id(i)]=ref(i);
  try{
   if(!(await repo.initializePartitioned(scope,state)).ok)throw Error('seed-failed');if(!(await repo.migrateSharedDirectory(scope,{operationId:'count_migration',expectedRevision:1})).ok)throw Error('migration-failed');
   const db=await base.open(),normalized=base.scopeOrThrow(scope);let result;
   active=true;await new Promise((resolve,reject)=>{const tx=db.transaction(['b23_states','b23_checkpoints','b23_operations','refs'],'readwrite');let error;repo.registerNativeReferences(tx,normalized,Array.from({length:50},(_,i)=>({...ref(3200+i),availability:'available'})),'count_register',()=>{},v=>{result=v;},e=>{error=e;tx.abort();},{preferDirectory:true,migrateLegacy:true});tx.oncomplete=resolve;tx.onabort=()=>reject(error??tx.error);});active=false;
   const counts=new Map();for(const row of rows){const old=counts.get(row.object)??{object:row.object,bucket:row.bucket,revision:row.revision,refs:row.refs,encodings:0};old.encodings++;counts.set(row.object,old);}
   const facts=(await repo.read(scope)).state;if(Object.keys(facts.refs).length!==3250||result?.added!==50)throw Error('incomplete-registration');
   return {added:result.added,refs:Object.keys(facts.refs).length,strictJSONCalls:rows.length,objects:[...counts.values()],calls:rows};
  }finally{active=false;base.close();}
 });
 assert(report.result.objects.some(x=>x.encodings>=4));report.status='MEASURED';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{
 for(const close of [()=>browser?.close(),()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))])try{await close();}catch(e){report.cleanupError=String(e);process.exitCode=1;}
 assert.equal(await readFile(root+path,'utf8'),source);await writeFile('/private/tmp/shared-piece-idb-count.json',JSON.stringify(report,null,2)+'\n');
}
console.log(JSON.stringify({status:report.status,browser:report.browserVersion,result:report.result&&{added:report.result.added,refs:report.result.refs,strictJSONCalls:report.result.strictJSONCalls,objectCount:report.result.objects.length,distribution:report.result.objects.reduce((a,v)=>(a[v.encodings]=(a[v.encodings]??0)+1,a),{})},error:report.error}));
