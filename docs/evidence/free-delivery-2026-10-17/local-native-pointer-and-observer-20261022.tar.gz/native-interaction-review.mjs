import {freeNavigationSnapshot} from 'file:///Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/src/navigation/free-view.mjs';
import {projectFreeSearch} from 'file:///Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/src/runtime/free-search-projection.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreeFrameClient} from 'file:///Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/src/host/free-frame-client.mjs';
const drain=async()=>{for(let i=0;i<60;i++)await Promise.resolve();};
const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
export function fixture(role='workspace',createClient=createFreeFrameClient){
 const nativePending=[];let time=1000,id=0,navOptions,views=0;const timers=new Map(),listeners=new Set(),messageListeners=new Set(),historicalMessages=[],parentMessages=[],calls=[],pages=[],states=[],presented=[],restoredViews=[];let factories=0,stops=0,invalidations=0,recoveryOptions,recoveryOpens=0,recoveryStops=0,backupOptions,backupOpens=0,backupStops=0,backupInvalidations=0,snippetOptions,snippetOpens=0,snippetStops=0,snippetInvalidations=0;
 const element=()=>({children:[],setAttribute(){},append(n){n.parent=this;this.children.push(n);},replaceChildren(){this.children=[];},remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);}});
 const body=element(),privateRoot=element();body.append(privateRoot);
 const focusEvents=new EventTarget();let panelFocuses=0;const document={addEventListener:focusEvents.addEventListener.bind(focusEvents),removeEventListener:focusEvents.removeEventListener.bind(focusEvents),body,createElement:element,defaultView:{parent:{postMessage(message,origin){parentMessages.push({message,origin});}}}};
 const grant=()=>({id:'grant',mountId:'mount',parentDocumentId:'parent',uiDocumentId:'ui',scopeGrantId:'scope',role,expiresAt:new Date(time+20000).toISOString()});
 const page=()=>({protocol:'vaiwl-free-frame/1',role,scope:'A',completeSnapshot:false,groups:{items:[]},entries:{noProject:{items:[]},unknown:{items:[]}},selection:null});
 let view=async()=>({ok:true,state:'ready',page:page(),navigation:[]});
 const runtime={connect:()=>({onMessage:{addListener:fn=>{messageListeners.add(fn);historicalMessages.push(fn);},removeListener:fn=>messageListeners.delete(fn)},onDisconnect:{addListener:f=>listeners.add(f),removeListener:f=>listeners.delete(f)},disconnect(){}}),sendMessage:async m=>{calls.push(m);if(m.type==='HOST_UI_VIEW'){views++;return view(m);}return {ok:true,grant:grant()};}};
 const client=createClient({document,privateRoot,runtime,role,parentOrigin:'https://chatgpt.com',onState:s=>states.push(s),now:()=>time,elapsedNow:()=>time,makeNonce:()=> 'nonce',schedule:(fn,ms)=>{const key=++id;timers.set(key,{fn,at:time+ms});return key;},cancel:key=>timers.delete(key),snippetsFactory:options=>{snippetOptions=options;return {open(){snippetOpens++;},stop(){snippetStops++;},invalidate(){snippetInvalidations++;}};},backupFactory:options=>{backupOptions=options;return {open(){backupOpens++;},stop(){backupStops++;},invalidate(){backupInvalidations++;}};},recoveryFactory:options=>{recoveryOptions=options;return {open(){recoveryOpens++;},stop(){recoveryStops++;}};},navigationFactory:options=>{factories++;navOptions=options;return {focusSurface:()=>{panelFocuses++;},setNativeNavigationPending:value=>nativePending.push(value),restoreFrameView:value=>restoredViews.push(value),invalidate(){invalidations++;},present:intent=>presented.push(intent),updateFrameProjection:p=>pages.push(p),stop:()=>{stops++;}};}});
 return {focusEvents,get panelFocuses(){return panelFocuses;},nativePending,parentMessages,restoredViews,jump(ms){time+=ms;},runtime,grant,presented,messageListeners,historicalMessages,emit:m=>{for(const fn of [...messageListeners])fn(m);},client,calls,pages,states,body,privateRoot,page,setView:fn=>{view=fn;},get snippets(){return snippetOptions;},get snippetOpens(){return snippetOpens;},get snippetStops(){return snippetStops;},get snippetInvalidations(){return snippetInvalidations;},get backup(){return backupOptions;},get backupOpens(){return backupOpens;},get backupStops(){return backupStops;},get backupInvalidations(){return backupInvalidations;},get recovery(){return recoveryOptions;},get recoveryOpens(){return recoveryOpens;},get recoveryStops(){return recoveryStops;},get invalidations(){return invalidations;},get nav(){return navOptions;},get factories(){return factories;},get stops(){return stops;},get views(){return views;},disconnect:()=>{for(const fn of [...listeners])fn();},async advance(ms){time+=ms;for(const [key,t]of [...timers])if(t.at<=time&&timers.has(key)){timers.delete(key);t.fn();}await drain();}};
}

{
 const f=fixture();await f.client.start();await drain();
 const oldNav=f.nav,old=oldNav.onNativeInteractionStart();f.emit({type:'VAIWL_UI_DATA_CHANGED'});f.client.stop();
 await f.client.start();await drain();const before=f.views,current=f.nav.onNativeInteractionStart();
 assert.equal(typeof current,'function');f.emit({type:'VAIWL_UI_DATA_CHANGED'});old();await drain();
 assert.equal(f.views,before,'retired release must not drain current dirty state');
 current();await drain();assert.equal(f.views,before+1);f.client.stop();
 console.log('PASS old release across stop/start preserves current hold and dirty flush');
}
{
 const f=fixture();await f.client.start();await drain();const before=f.views,release=f.nav.onNativeInteractionStart();
 f.emit({type:'VAIWL_UI_DATA_CHANGED'});await drain();assert.equal(f.views,before);
 f.jump(1001);f.emit({type:'VAIWL_UI_DATA_CHANGED'});await drain();assert.equal(f.views,before+1,'late timer cannot prolong hold beyond elapsed ceiling');
 release();await f.advance(0);assert.equal(f.views,before+1);f.client.stop();
 console.log('PASS elapsed ceiling drains dirty even before delayed timer runs');
}
