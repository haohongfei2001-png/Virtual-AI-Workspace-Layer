import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {observeFaultBodyStream,BODY_STREAM_KIND} from 'file:///Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/fault-body-stream-observer.mjs';

const extensionId='a'.repeat(32),origin='http://127.0.0.1:12345',path='/backend-api/conversation/33333333-3333-4333-8333-333333333333';
const body=JSON.stringify({protocol:'future-99',payload:{opaque:true}}),base64=s=>Buffer.from(s).toString('base64');
const tick=()=>new Promise(resolve=>setImmediate(resolve));
class Transport extends EventEmitter {
 calls=[];commands=[];streamReply=null;readbackError=null;attach=null;
 async send(method,params={}) {
  this.calls.push({method,params});
  if(method==='Target.getTargets')return {targetInfos:[{type:'service_worker',url:`chrome-extension://${extensionId}/extension/worker.mjs`,targetId:'worker'}]};
  if(method==='Target.attachToTarget')return this.attach??{sessionId:'network'};
  if(method==='Target.detachFromTarget')return {};
  assert.equal(method,'Target.sendMessageToTarget');assert.equal(params.sessionId,'network');
  const command=JSON.parse(params.message);this.commands.push(command);
  if(command.method==='Network.enable')this.reply(command,{});
  else if(command.method==='Network.streamResourceContent')this.streamReply=()=>this.reply(command,{bufferedData:base64(this.prefix??body)});
  else if(command.method==='Network.getResponseBody')this.reply(command,this.readbackError?null:{body,base64Encoded:false},this.readbackError);
  else assert.fail('unexpected Network command');
  return {};
 }
 reply(command,result,error){this.emit('Target.receivedMessageFromTarget',{sessionId:'network',message:JSON.stringify({id:command.id,...(error?{error:{message:error}}:{result})})});}
 event(method,params,sessionId='network'){this.emit('Target.receivedMessageFromTarget',{sessionId,message:JSON.stringify({method,params})});}
 start(id='r'){this.event('Network.requestWillBeSent',{requestId:id,request:{method:'GET',url:origin+path}});}
 response(id='r',url=origin+path){this.event('Network.responseReceived',{requestId:id,response:{url,status:200}});}
 data(data,id='r',included=true){this.event('Network.dataReceived',{requestId:id,dataLength:Buffer.byteLength(data),...(included?{data:base64(data)}:{})});}
 end(id='r',failed=false){this.event(failed?'Network.loadingFailed':'Network.loadingFinished',{requestId:id,...(failed?{errorText:'net::ERR_ABORTED'}:{encodedDataLength:83})});}
}

const results=[];
for(const mode of ['data-after-finished','response-after-finished','inspector-target-crashed','target-crashed','finish-new-readback']){
 const p=new Transport(),observer=await observeFaultBodyStream(p,{extensionId,origin});
 p.start();
 let lateReadback;
 if(mode==='response-after-finished'){
  p.end();p.response();p.data(body,'r',false);p.streamReply();
 }else{
  p.prefix=mode==='data-after-finished'?body.slice(0,10):body;
  p.response();p.data(p.prefix,'r',false);
  if(mode==='data-after-finished'){p.end();p.data(body.slice(10));p.streamReply();}
  else if(mode==='inspector-target-crashed'){p.streamReply();p.event('Inspector.targetCrashed',{});p.end();}
  else if(mode==='target-crashed'){p.streamReply();p.emit('Target.targetCrashed',{targetId:'worker',status:'crashed',errorCode:1});p.end();}
  else {
   const original=p.send.bind(p);
   p.send=async(method,params={})=>{if(method==='Target.sendMessageToTarget'){
    const command=JSON.parse(params.message);
    if(command.method==='Network.getResponseBody'){p.calls.push({method,params});p.commands.push(command);lateReadback=()=>p.reply(command,{body,base64Encoded:false});return {};}
   }return original(method,params);};
   const finishing=observer.finish();p.end();p.streamReply();
   const r=await finishing;const againBefore=JSON.stringify(await observer.finish());lateReadback?.();await tick();
   results.push({mode,captureComplete:r.captureComplete,terminalReason:r.terminalReason,readback:r.rows[0]?.readback?.state,readbackCommandIssued:!!lateReadback,lateReadbackDiscarded:JSON.stringify(await observer.finish())===againBefore});continue;
  }
 }
 const r=await observer.finish();results.push({mode,captureComplete:r.captureComplete,terminalReason:r.terminalReason,networkBodyComplete:r.rows[0]?.networkBodyComplete,readback:r.rows[0]?.readback?.state});
}
console.log(JSON.stringify(results,null,2));
assert(results.every(r=>r.captureComplete===false),'invalid sequence or unfinished settlement must not be captureComplete');
