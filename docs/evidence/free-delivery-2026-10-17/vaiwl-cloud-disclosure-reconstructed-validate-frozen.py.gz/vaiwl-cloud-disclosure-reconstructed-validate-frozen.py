import datetime,hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/workspace/shared/vaiwl-cloud-reconstructed-20261020'); out=pathlib.Path('/workspace/shared/vaiwl-recovery/reconstructed')
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src','extension','tests','tools','.github'],cwd=root,text=True).splitlines()
def hashes(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(files))}
before=hashes(); (out/'candidate-input-hashes.json').write_text(json.dumps(before,indent=2)+'\n')
results={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':'029175be91799fcf1ba25b9a8142c439987b8af9','node':subprocess.check_output(['node','--version'],text=True).strip(),'inputFiles':len(before),'runs':[],'provenance':'New reconstruction, not a recovered old candidate or reconstructed historical logs.'}
tests=sorted(str(p.relative_to(root)) for p in (root/'tests').rglob('*.test.mjs') if 'node_modules' not in p.parts)
commands=[('full-node.tap',['node','--test','--test-reporter=tap','--test-concurrency=2',*tests]),('build.json',['node','extension/package.mjs',str(out/'package')]),('verify.json',['node','extension/package.mjs','--verify',str(out/'package'/'extension')]),('guard-mutations.log',['node','tests/host/guard-mutations.runner.mjs','--report',str(out/'guard-mutations.json')])]
for name,command in commands:
 start=time.monotonic()
 with (out/name).open('w') as log: run=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results['runs'].append({'artifact':name,'command':command if name!='full-node.tap' else 'node --test --test-reporter=tap --test-concurrency=2 ALL603TESTFILES','returncode':run.returncode,'wallSeconds':time.monotonic()-start})
 results['sourceUnchanged']=before==hashes();results['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'full-validation.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,run.returncode,'unchanged',results['sourceUnchanged'],flush=True)
 if run.returncode or not results['sourceUnchanged']:raise SystemExit(1)
