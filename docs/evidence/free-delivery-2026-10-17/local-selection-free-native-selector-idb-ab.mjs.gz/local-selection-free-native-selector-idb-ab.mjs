import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs');
const {createServer}=await import(root+'simulator/server.mjs');
const hash=s=>createHash('sha256').update(s).digest('hex');
const files=['native-version-index.mjs','native-index-reader.mjs','native-repository.mjs'].map(p=>'src/data/'+p);
const baseline=Object.fromEntries(files.map(p=>[p,execFileSync('git',['show','f3af526:'+p],{cwd:root,encoding:'utf8'})]));
const candidate=Object.fromEntries(await Promise.all(files.map(async p=>[p,await readFile(root+p,'utf8')])));
assert(files.some(p=>baseline[p]!==candidate[p]));
const paths=(await readdir(root+'src',{recursive:true})).filter(p=>p.endsWith('.mjs')).map(p=>'src/'+p);
const hashes=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await readFile(root+p))])));
const sourceHashes=await hashes(),server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
const report={evidence:'DIAGNOSTIC_REAL_CHROME_IDB_OFFSET_PAGE_SELECTOR_AB',hostAcceptance:'NOT_ESTABLISHED',baseline:'f3af526',sourceHashes,moduleHashes:Object.fromEntries(files.map(p=>[p,{baseline:hash(baseline[p]),candidate:hash(candidate[p])}])),scope:'Identical deterministic 10000-ref database in fresh contexts; original 500-row offset pages; all directory and fact checks; no Host observer or writer contention',rows:[]};let browser;
try{
 browser=await chromium.launch({headless:true,executablePath:process.env.FREE_CHROME_EXECUTABLE??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});report.browserVersion=browser.version();
 for(const [round,order]of [[0,['baseline','candidate']],[1,['candidate','baseline']],[2,['baseline','candidate']]])for(const variant of order){
  const context=await browser.newContext();await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();if(u.pathname==='/hf/A/c/T0')return route.fulfill({status:200,contentType:'text/html',body:'<!doctype html><title>Isolated IDB diagnostic</title>'});const p=u.pathname.slice(1);return files.includes(p)?route.fulfill({status:200,contentType:'text/javascript',body:(variant==='baseline'?baseline:candidate)[p]}):route.continue();});
  try{
   const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');let timer;
   const result=await Promise.race([page.evaluate(async()=>{
    const [{ScopeRepository},{NativeRepository},{scopeOf},{emptyNativeFacts,applyNativeObservations},{saveNativePieces,nativeRecord},{buildNativeVersionIndex},{digest}]=await Promise.all(['/src/b1/scope-repository.mjs','/src/data/native-repository.mjs','/simulator/data.mjs','/src/data/native-facts.mjs','/src/data/native-partitions.mjs','/src/data/native-version-index.mjs','/src/data/hash.mjs'].map(p=>import(p)));
    const base=new ScopeRepository({indexedDB,databaseName:'native-selector-ab'}),scope=scopeOf('A'),normalized=base.scopeOrThrow(scope),empty=emptyNativeFacts(scope),size=10000,P='g-p-'+'a'.repeat(32),id=i=>'60000000-0000-4000-8000-'+i.toString(16).padStart(12,'0');
    const batch={scopeKey:empty.scopeKey,sourceRevision:1,observedAt:'2026-10-13T00:00:00Z',validUntil:'2026-10-14T00:00:00Z',projects:[{id:P,nativeName:'Project',nativeUrl:'https://fixture.test/project/'+P,availability:'available'}],refs:Array.from({length:size},(_,i)=>({id:id(i),nativeTitle:'Conversation '+i,nativeUrl:'https://fixture.test/c/'+id(i),availability:'available'})),membership:Array.from({length:size},(_,i)=>({id:id(i),state:'PROJECT',projectId:P})),inventory:{projects:'complete',conversations:'complete',cursor:null}};
    try{
     const options={scope,channel:'synthetic',sourceId:'fixture',generation:'first',now:batch.observedAt};const first=applyNativeObservations(empty,{...batch,refs:batch.refs.slice(0,5000),membership:batch.membership.slice(0,5000)},options),facts=applyNativeObservations(first,{...batch,sourceRevision:2,refs:batch.refs.slice(5000),membership:batch.membership.slice(5000)},options);
     const records=new Map(),manifest=saveNativePieces({put:r=>records.set(r.key,structuredClone(r))},scope,empty,facts,null,{batch}),built=buildNativeVersionIndex(manifest,scope);for(const row of built.records)records.set(row.key,row);records.set(normalized.key,nativeRecord(normalized.key,built.root));
     const db=await base.open();await new Promise((resolve,reject)=>{const tx=db.transaction(['native_states','native_operations'],'readwrite');for(const row of records.values())tx.objectStore('native_states').put(row);tx.objectStore('native_operations').put(nativeRecord(normalized.key,{revision:built.root.revision}));tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});
     const repository=new NativeRepository({baseRepository:base}),revision=await repository.version(scope),rows=[],pageMs=[];let offset=0;
     for(;;){const at=performance.now(),page=await repository.page(scope,{revision,offset,limit:500});pageMs.push(performance.now()-at);if(page.total!==10001||page.revision!==revision||page.offset!==offset)throw Error('invalid-page');
      for(const key of page.selectedProjects)rows.push(['project',key,page.facts.projects[key]]);
      for(const key of page.selectedRefs){if(page.facts.membership[key]?.projectId!==P)throw Error('wrong-member');rows.push(['ref',key,page.facts.refs[key],page.facts.membership[key],page.facts.projects[P]]);}
      if(page.nextOffset===page.total)break;if(page.nextOffset<=offset)throw Error('stalled-page');offset=page.nextOffset;
     }
     if(await repository.version(scope)!==revision||rows.length!==10001||pageMs.length!==21||rows.filter(r=>r[0]==='ref').some((r,i)=>r[1]!==id(i)))throw Error('invalid-complete-audit');
     return {totalPageMs:pageMs.reduce((s,n)=>s+n,0),pageMs,pages:pageMs.length,total:rows.length,revision,factsMembershipOrderHash:digest(rows),seedHash:digest(facts)};
    }finally{base.close();}
   }),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('diagnostic-evaluation-deadline')),60000);})]).finally(()=>clearTimeout(timer));
   report.rows.push({round,variant,...result});console.log(JSON.stringify({round,variant,totalPageMs:result.totalPageMs}));
  }finally{await context.close();}
 }
 assert.equal(new Set(report.rows.map(r=>r.factsMembershipOrderHash)).size,1);assert.equal(new Set(report.rows.map(r=>r.seedHash)).size,1);report.status='MEASURED_NOT_HOST_ACCEPTANCE';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{
 for(const [stage,close]of [['browser',()=>browser?.close()],['server',()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))],['source-integrity',async()=>assert.deepEqual(await hashes(),sourceHashes)]])try{await close();}catch(error){(report.cleanupErrors??=[]).push({stage,error:String(error)});report.status='FAIL';process.exitCode=1;}
 await writeFile('/private/tmp/free-native-selector-idb-ab.json',JSON.stringify(report,null,2)+'\n');
}
