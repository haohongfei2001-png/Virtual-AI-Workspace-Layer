import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const root='file:///Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const [{MockIDBFactory},{ScopeRepository},{NativeRepository},{scopeOf},{emptyNativeFacts,applyNativeObservations},{saveNativePieces,nativeRecord},{buildNativeVersionIndex}]=await Promise.all(['tests/b23/mock-idb.mjs','src/b1/scope-repository.mjs','src/data/native-repository.mjs','simulator/data.mjs','src/data/native-facts.mjs','src/data/native-partitions.mjs','src/data/native-version-index.mjs'].map(p=>import(root+p)));
const base=new ScopeRepository({indexedDB:new MockIDBFactory(),databaseName:'exact-tail-diagnostic'}),scope=scopeOf('A'),normalized=base.scopeOrThrow(scope),empty=emptyNativeFacts(scope),size=10000,P='g-p-'+ 'a'.repeat(32),id=i=>'60000000-0000-4000-8000-'+i.toString(16).padStart(12,'0');
const batch={scopeKey:empty.scopeKey,sourceRevision:1,observedAt:'2026-10-13T00:00:00Z',validUntil:'2026-10-14T00:00:00Z',projects:[{id:P,nativeName:'Project',nativeUrl:'https://fixture.test/project/'+P,availability:'available'}],refs:Array.from({length:size},(_,i)=>({id:id(i),nativeTitle:'Conversation '+i,nativeUrl:'https://fixture.test/c/'+id(i),availability:'available'})),membership:Array.from({length:size},(_,i)=>({id:id(i),state:'PROJECT',projectId:P})),inventory:{projects:'complete',conversations:'complete',cursor:null}};
const first=applyNativeObservations(empty,{...batch,refs:batch.refs.slice(0,5000),membership:batch.membership.slice(0,5000)},{scope,channel:'synthetic',sourceId:'fixture',generation:'first',now:batch.observedAt});
const facts=applyNativeObservations(first,{...batch,sourceRevision:2,refs:batch.refs.slice(5000),membership:batch.membership.slice(5000)},{scope,channel:'synthetic',sourceId:'fixture',generation:'first',now:batch.observedAt}),records=new Map(),manifest=saveNativePieces({put:r=>records.set(r.key,structuredClone(r))},scope,empty,facts,null,{batch}),built=buildNativeVersionIndex(manifest,scope);
for(const row of built.records)records.set(row.key,row);records.set(normalized.key,nativeRecord(normalized.key,built.root));
const db=await base.open();await new Promise((resolve,reject)=>{const tx=db.transaction(['native_states','native_operations'],'readwrite');for(const row of records.values())tx.objectStore('native_states').put(row);tx.objectStore('native_operations').put(nativeRecord(normalized.key,{revision:built.root.revision}));tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});
let active=null;const original=db.transaction.bind(db);db.transaction=(names,mode='readonly')=>{const tx=original(names,mode);if(active){active.transactions++;active.modes.push(mode);}const originalStore=tx.objectStore.bind(tx);tx.objectStore=name=>{const store=originalStore(name);for(const method of ['get','put','openCursor','openKeyCursor']){if(typeof store[method]!=='function')continue;const fn=store[method].bind(store);store[method]=(...args)=>{if(active){const kind=name+'.'+method;active.operations[kind]=(active.operations[kind]??0)+1;if(method==='get')active.readKeys.push(args[0]);}return fn(...args);};}return store;};return tx;};
const report={evidence:'MOCK_IDB_LOGICAL_COUNTS_NOT_BROWSER_PERFORMANCE',size,rows:[]};
async function audit(kind){
 const repository=new NativeRepository({baseRepository:base});active={label:kind,transactions:0,modes:[],operations:{},readKeys:[]};const metric=active;
 const revision=await repository.version(scope);let header=null,keys=null;
 if(kind==='header_ids'){header=await repository.header(scope);assert.equal(header.revision,revision);keys=[...Object.keys(header.manifest.projects).map(id=>['projects',id]),...Object.keys(header.manifest.refs).map(id=>['refs',id])];}
 let offset=0;const rows=[];let pages=0,total;
 for(;;){const ids=keys?{projects:keys.slice(offset,offset+500).filter(x=>x[0]==='projects').map(x=>x[1]),refs:keys.slice(offset,offset+500).filter(x=>x[0]==='refs').map(x=>x[1])}:null;
 const page=await repository.page(scope,{revision,offset,limit:500,...(ids?{ids}:{})});pages++;assert.equal(page.revision,revision);assert.equal(page.total,10001);total=page.total;
 for(const id of page.selectedProjects)rows.push(['project',id,page.facts.projects[id]]);
 for(const id of page.selectedRefs)rows.push(['ref',id,page.facts.refs[id],page.facts.membership[id],page.facts.projects[page.facts.membership[id].projectId]]);
 if(page.nextOffset===total)break;offset=page.nextOffset;}
 assert.equal(await repository.version(scope),revision);active=null;
 const {readKeys,modes,...summary}=metric;summary.readonly=modes.every(x=>x==='readonly');summary.pages=pages;summary.total=total;summary.indexBucketReads=readKeys.filter(k=>k.includes('native-version-index')).length;summary.factPieceReads=readKeys.filter(k=>k.includes('native-piece')).length;report.rows.push(summary);return rows;
}
const offset=await audit('offset'),targeted=await audit('header_ids');assert.deepEqual(targeted,offset);report.exactFactsMembershipOrderTotalEqual=true;
// A same-revision physical corruption after a valid HEADER is not a permitted
// writer update, but demonstrates a real detection difference between APIs.
const repository=new NativeRepository({baseRepository:base}),header=await repository.header(scope);
const pieces=built.records.filter(r=>r.payload.kind==='refs');const row=structuredClone(pieces[0]);const own=new Set(row.payload.ordinals);const other=pieces.find(p=>p.payload.ordinals.some(n=>!own.has(n)));row.payload.ordinals[0]=other.payload.ordinals.find(n=>!own.has(n));
await new Promise((resolve,reject)=>{const tx=db.transaction('native_states','readwrite');tx.objectStore('native_states').put(nativeRecord(row.key,row.payload));tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});
let error;try{await repository.page(scope,{revision:header.revision,offset:0,limit:500});}catch(e){error=e.message;}assert.equal(error,'invalid-native-index-order');
const all=[...Object.keys(header.manifest.projects).map(id=>['projects',id]),...Object.keys(header.manifest.refs).map(id=>['refs',id])];let returned=0;
for(let start=0;start<all.length;start+=500){const part=all.slice(start,start+500);const page=await repository.page(scope,{revision:header.revision,offset:start,limit:500,ids:{projects:part.filter(x=>x[0]==='projects').map(x=>x[1]),refs:part.filter(x=>x[0]==='refs').map(x=>x[1])}});returned+=page.selectedProjects.length+page.selectedRefs.length;}
assert.equal(await repository.version(scope),header.revision);assert.equal(returned,10001);report.sameRevisionPostHeaderCorruption={injection:'cross-bucket duplicate ordinal with recomputed checksum; root and marker unchanged',offsetRejects:error,headerIdsCompletes:true,returned};
await writeFile('/private/tmp/native-pagination-comparison.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));base.close();
