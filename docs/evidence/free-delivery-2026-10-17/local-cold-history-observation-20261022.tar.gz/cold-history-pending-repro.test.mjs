import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createBrowserRequestContext} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/src/runtime/browser-request-context.mjs';
const source='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/src/runtime/browser-request-context.mjs';
console.log('source-sha256',createHash('sha256').update(readFileSync(source)).digest('hex'));
globalThis.fetch=()=>{throw Error('network-forbidden-in-event-fixture');};
const origin='https://chatgpt.com',C='11111111-1111-4111-8111-111111111111',D='22222222-2222-4222-8222-222222222222';
const flush=()=>new Promise(resolve=>setImmediate(resolve));
function event(){const listeners=new Set();return {addListener:f=>listeners.add(f),removeListener:f=>listeners.delete(f),emit:d=>{for(const f of listeners)f(d);}};}
function fixture(t){
 let time=1000,current={documentId:'doc',documentLifecycle:'active',frameType:'outermost_frame',url:origin+'/c/'+C},seq=0;
 const ready=[],invalidated=[],webRequest=Object.fromEntries(['onSendHeaders','onCompleted','onErrorOccurred','onBeforeRedirect'].map(k=>[k,event()]));
 const owner=createBrowserRequestContext({webRequest,origin,getTab:async id=>({id,incognito:false}),getFrame:async()=>current,associatePage:async q=>({...q,association:'explicit-body-id'}),now:()=>time,elapsedNow:()=>time,makeId:()=>`fixture_${++seq}`,onReady:x=>ready.push(x),onInvalidate:x=>invalidated.push(x)});t.after(()=>owner.stop());
 const details=(id,patch={})=>({tabId:7,frameId:0,documentId:'doc',documentLifecycle:'active',initiator:origin,type:'xmlhttprequest',method:'GET',requestId:'request_'+(++seq),url:origin+'/backend-api/conversation/'+id,requestHeaders:[{name:'Chatgpt-Account-Id',value:'team'}],...patch});
 const send=(id,patch={})=>{const d=details(id,patch);webRequest.onSendHeaders.emit(d);return d;};
 const history=(id,patch={})=>owner.invalidateHistory({tabId:7,frameId:0,documentId:'doc',documentLifecycle:'active',frameType:'outermost_frame',url:origin+'/c/'+id,...patch});
 return {owner,send,history,ready,invalidated,webRequest,route:id=>{current={...current,url:origin+'/c/'+id};},advance:ms=>{time+=ms;},finish:async d=>{webRequest.onCompleted.emit({...d,statusCode:200,fromCache:false,requestHeaders:undefined});await flush();},verify:id=>owner.verify({tabId:7,frameId:0,documentId:'doc',documentLifecycle:'active',incognito:false,actualURL:origin+'/c/'+id})};
}
test('control: cold current-route GET without history establishes independent C2 receipt',async t=>{const f=fixture(t);f.route(D);await f.finish(f.send(D));assert.equal((await f.verify(D))?.conversationId,D);assert.equal(f.ready.length,1);});
test('control: history delivered before cold GET establishes independent C2 receipt',async t=>{const f=fixture(t);f.route(D);f.history(D);await f.finish(f.send(D));assert.equal((await f.verify(D))?.conversationId,D);assert.equal(f.ready.length,1);});
test('control: existing-receipt pending new-route GET survives history and revokes old receipt',async t=>{const f=fixture(t);await f.finish(f.send(C));const old=await f.verify(C);assert(old);f.route(D);const request=f.send(D);f.history(D);assert.equal(await f.verify(C),null);await f.finish(request);assert.equal((await f.verify(D))?.conversationId,D);assert.equal(f.ready.length,2);});
test('REPRO: cold pending GET must survive exact same-document history arriving before first prepare',async t=>{const f=fixture(t);f.route(D);const request=f.send(D);f.history(D);await f.finish(request);assert.equal((await f.verify(D))?.conversationId,D,'matching cold GET was erased solely because history followed send');assert.equal(f.ready.length,1);});
test('counterexample: history alone never creates a receipt',async t=>{const f=fixture(t);f.route(D);f.history(D);assert.equal(await f.verify(D),null);assert.equal(f.ready.length,0);});
test('counterexamples: malformed or unrelated history cannot retain a cold pending GET',async t=>{for(const patch of [{documentId:'other'},{frameId:1},{frameType:'sub_frame'},{documentLifecycle:'prerender'},{url:origin+'/c/'+C}]){const f=fixture(t);f.route(D);const request=f.send(D);f.history(D,patch);await f.finish(request);assert.equal(await f.verify(D),null,JSON.stringify(patch));assert.equal(f.ready.length,0);}});
test('counterexamples: accepted request, conflict, second history, expiration, stop never revive cold work',async t=>{for(const mode of ['accepted','conflict','second-history','expiry','stop']){const f=fixture(t);f.route(D);const request=f.send(D);if(mode==='accepted')await flush();if(mode==='conflict')f.send(D,{requestHeaders:[{name:'Chatgpt-Account-Id',value:'other'}]});f.history(D);if(mode==='second-history')f.history(D);if(mode==='expiry')f.advance(6000);if(mode==='stop')f.owner.stop();await f.finish(request);assert.equal(await f.verify(D),null,mode);assert.equal(f.ready.length,0,mode);}});
