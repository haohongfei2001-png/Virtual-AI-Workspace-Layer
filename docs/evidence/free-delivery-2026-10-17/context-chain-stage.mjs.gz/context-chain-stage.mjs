import {readFileSync,writeFileSync,mkdtempSync,cpSync} from 'node:fs';
import {join} from 'node:path';import {createHash} from 'node:crypto';
import {packageHost,verifyHost} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/extension/package.mjs';
import {compileClassicWorker} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/extension/classic-worker-build.mjs';
const directory=mkdtempSync('/private/tmp/vaiwl-context-chain-'),normal=packageHost(join(directory,'normal'),{observedChatGPTContext:true}),temporary=packageHost(join(directory,'temporary'),{observedChatGPTContext:true,temporaryReadOnly:true}),old='/private/tmp/vaiwl-live-candidate-1ad3dac/extension';
const hash=s=>createHash('sha256').update(s).digest('hex'),manifest=JSON.parse(readFileSync(join(old,'manifest.json'))),changes=[];
for(const pkg of [normal,temporary]){verifyHost(pkg.unpacked);const candidate=JSON.parse(readFileSync(join(pkg.unpacked,'manifest.json')));for(const key of ['permissions','host_permissions','optional_permissions','optional_host_permissions','key'])if(JSON.stringify(candidate[key])!==JSON.stringify(manifest[key]))throw Error('permissions-changed');}
const recorder=`const __liveStep=code=>{try{const a=globalThis.__vaiwlContextStages??=[];if(a.length<96)a.push({n:a.length,at:Math.round(performance.now()),code});}catch{}};\n`;
function edit(path,pairs,{prefix=true}={}){const file=join(normal.unpacked,path),original=readFileSync(file,'utf8');let value=original;for(const [from,to]of pairs){if(value.split(from).length!==2)throw Error('probe-anchor:'+path);value=value.replace(from,to);}if(prefix)value=recorder+value;writeFileSync(file,value);changes.push({path,originalSha256:hash(original),instrumentedSha256:hash(value)});}
edit('src/runtime/browser-request-context.mjs',[
 ['function send(details){','function send(details){__liveStep("native-send");'],
 ['if(!validDetails(details))return;','if(!validDetails(details))return;__liveStep("native-valid-details");'],
 ['if(!conversationId&&!projectId)return;','if(!conversationId&&!projectId)return;__liveStep("native-allowed-endpoint");'],
 ['requests.set(request.requestId,request);','requests.set(request.requestId,request);__liveStep("native-tracked");'],
 ['request.epoch=document.epoch;request.accepted=true;return true;','request.epoch=document.epoch;request.accepted=true;__liveStep("native-prepared");return true;'],
 ['function complete(details){','function complete(details){__liveStep(requests.has(details?.requestId)?"complete-tracked":"complete-untracked");__liveStep(details?.statusCode===200?"native-200":"native-not-200");__liveStep(details?.fromCache===true?"native-cached":"native-not-cached");'],
 ['r.document.receipt=receipt;','__liveStep("receipt-issued");r.document.receipt=receipt;'],
 ['const receipt=documents.get(key(frame))?.receipt;if(signal?.aborted||!isCurrent(frame,receipt))return null;','const receipt=documents.get(key(frame))?.receipt;__liveStep(receipt?"verify-has-receipt":"verify-no-receipt");if(signal?.aborted||!isCurrent(frame,receipt))return null;__liveStep("verify-current-receipt");'],
 ['if(!current()||answer?.challenge!==challenge','__liveStep(answer==null?"association-null":"association-present");if(!current()||answer?.challenge!==challenge'],
 ['const [actual,tab]=await Promise.all','__liveStep("association-matched");const [actual,tab]=await Promise.all'],
 ['function drop(document,reason){','function drop(document,reason){__liveStep(reason===\'navigation\'?"receipt-drop-navigation":"receipt-drop-other");'],
 ['function invalidateCommitted(details){','function invalidateCommitted(details){__liveStep("navigation-committed");'],
 ['function invalidateHistory(details){','function invalidateHistory(details){__liveStep("navigation-history");'],
 ['function stop(){','__liveStep("listeners-registered");function stop(){']
]);
edit('src/runtime/context-recovery/no-receipt-recovery.mjs',[
 ['function status(f,state,reason){','function status(f,state,reason){__liveStep(["CHECKING","WAITING_NATIVE","BLOCKED","AUTHORIZING","SCOPE_VERIFIED"].includes(state)?"recovery-"+state:"recovery-other");'],
 ['f.result=result;','__liveStep(result?.state===\'verified\'?"authorization-verified":result?.reason===\'host-verification-required\'?"authorization-challenged":result?.reason===\'scope-provider-unavailable\'?"authorization-provider-unavailable":"authorization-other");f.result=result;']
]);
edit('src/runtime/session-provider.mjs',[
 ['const target=origin+path,response=await fetch','__liveStep(path===\'/api/auth/session\'?"session-start":path.startsWith(\'/backend-api/accounts/\')?"accounts-start":"current-read-start");const target=origin+path,response=await fetch'],
 ['return readSessionJSON(response,','__liveStep(response.status===200?"identity-200":response.status===403?"identity-403":response.status===401?"identity-401":"identity-other");__liveStep(response.headers.get(\'cf-mitigated\')===\'challenge\'?"identity-challenge":"identity-no-challenge-header");return readSessionJSON(response,']
]);
edit('src/runtime/host-worker-runtime.mjs',[
 ['const message=(value,sender,reply)=>{','const message=(value,sender,reply)=>{if(["HOST_HELLO","HOST_REFRESH"].includes(value?.type))__liveStep(value.type);'],
 ['.then(result=>{if(active)reply(result);}', '.then(result=>{if(value?.type===\'HOST_REFRESH\')__liveStep(result?.state===\'verified\'?"refresh-verified":result?.reason===\'current-context-unproven\'?"refresh-context-unproven":result?.reason===\'host-verification-required\'?"refresh-challenged":"refresh-other");if(active)reply(result);}']
]);
edit('extension/content-entry.mjs',[
 ['adapterFactory:options=>createChatGPTAdapter({...options,profile})','adapterFactory:options=>{const adapter=createChatGPTAdapter({...options,profile});globalThis.__vaiwlPreauthObservation=()=>adapter.observationStatus();return adapter;}'],
 ['void session.start();','globalThis.__vaiwlPreauthStatus=()=>session.localStatus();void session.start();']
],{prefix:false});
const compiled=compileClassicWorker(normal.unpacked);for(const [path,value]of [['extension/worker.mjs',compiled.entry],['extension/classic-runtime.js',compiled.runtime]]){const file=join(normal.unpacked,path);changes.push({path,originalSha256:hash(readFileSync(file)),instrumentedSha256:hash(value)});writeFileSync(file,value);}
const info=JSON.parse(readFileSync(join(normal.unpacked,'build-manifest.json')));for(const [path,h]of Object.entries(info.files)){const change=changes.find(c=>c.path===path);if(change&&change.originalSha256!==h||hash(readFileSync(join(normal.unpacked,path)))!==(change?.instrumentedSha256??h))throw Error('diagnostic-integrity');}
const stage={directory,normal:normal.unpacked,temporary:temporary.unpacked,old,changes,sourceHashes:info.sourceHashes,permissionsUnchanged:true,recorder:'96 static enum codes plus relative milliseconds; no IDs URLs headers bodies or scope'};writeFileSync('/private/tmp/vaiwl-context-stage.json',JSON.stringify(stage,null,2));console.log(JSON.stringify({directory,stage:'/private/tmp/vaiwl-context-stage.json',modifiedFiles:changes.map(c=>c.path)}));
