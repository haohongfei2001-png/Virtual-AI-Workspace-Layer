import {connect} from './vaiwl-cdp-helper.mjs';
import {readFile,writeFile} from 'node:fs/promises';
const c=await connect(),sessions=[];const report={kind:'AUTHORIZED_SESSION_RESPONSE_METADATA_ONLY',bodyRead:false,credentialRead:false,nativeWrites:0,at:new Date().toISOString()};
try{
 const wanted=JSON.parse(await readFile('/private/tmp/vaiwl-dedicated-target.json','utf8')).targetId;
 const targets=(await c.send('Target.getTargets')).targetInfos;
 const page=targets.find(t=>t.targetId===wanted&&t.type==='page'&&new URL(t.url).origin==='https://chatgpt.com');
 if(!page)throw Error('authorized-target-unavailable');
 let worker=targets.find(t=>t.type==='service_worker'&&t.url==='chrome-extension://hdffnmlfhkgijgdllmmcefoamliigmao/extension/worker.mjs');

 if(!worker){const {sessionId}=await c.send('Target.attachToTarget',{targetId:page.targetId,flatten:true});sessions.push(sessionId);await c.send('ServiceWorker.enable',{},sessionId);await c.send('ServiceWorker.startWorker',{scopeURL:'chrome-extension://hdffnmlfhkgijgdllmmcefoamliigmao/'},sessionId);worker=(await c.send('Target.getTargets')).targetInfos.find(t=>t.type==='service_worker'&&t.url==='chrome-extension://hdffnmlfhkgijgdllmmcefoamliigmao/extension/worker.mjs');}
 const expression=`(async()=>{const started=performance.now();try{const r=await fetch('https://chatgpt.com/api/auth/session',{method:'GET',credentials:'include',cache:'no-store',redirect:'error',signal:AbortSignal.timeout(6000),headers:{Accept:'application/json'}});const result={status:r.status,mime:r.headers.get('content-type')?.split(';')[0]??null,challenge:r.headers.get('cf-mitigated')==='challenge',cloudflare:r.headers.get('server')==='cloudflare',redirected:r.redirected,exactURL:r.url==='https://chatgpt.com/api/auth/session',elapsedMs:Math.round(performance.now()-started)};await r.body?.cancel();return result;}catch(e){return {failure:['AbortError','TimeoutError','TypeError'].includes(e.name)?e.name:'other',elapsedMs:Math.round(performance.now()-started)}}})()`;
 for(const [kind,target] of [['worker',worker]]){
  if(!target){report[kind]={available:false};continue;}
  const {sessionId}=await c.send('Target.attachToTarget',{targetId:target.targetId,flatten:true});sessions.push(sessionId);
  const result=await c.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId);
  report[kind]=result.exceptionDetails?{failure:'evaluation-exception'}:result.result.value;
 }
}catch(e){report.failure=e.message.startsWith('cdp-timeout')?'cdp-timeout':e.message==='authorized-target-unavailable'?e.message:'diagnostic-error';}
finally{for(const sessionId of sessions)await c.send('Target.detachFromTarget',{sessionId}).catch(()=>{});c.close();await writeFile('/private/tmp/vaiwl-session-worker-20261019.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));}
