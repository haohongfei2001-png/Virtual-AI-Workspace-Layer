import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/';
const {chromium}=await import(root+'tests/b1/tooling/node_modules/playwright/index.mjs'),{createServer}=await import(root+'simulator/server.mjs');
const path='src/data/repository.mjs',source=await readFile(root+path,'utf8');
const begin=source.indexOf('  registerNativeReferences('),end=source.indexOf('  async exportBackup(',begin);assert(begin>=0&&end>begin);
let part=source.slice(begin,end);
const patch=(from,to)=>{assert.equal(part.split(from).length,2);part=part.replace(from,to);};
patch("    const s=scopeChecked(scope),store=tx.objectStore('b23_states');","    globalThis.__phaseMark?.('register');const s=scopeChecked(scope),store=tx.objectStore('b23_states');");
patch('    request.onsuccess=()=>{try{','    request.onsuccess=()=>{globalThis.__phaseMark?.("root");try{');
patch('      const apply=(current,storage=null)=>{try{','      const apply=(current,storage=null)=>{globalThis.__phaseMark?.("apply");try{');
patch("        const duplicate=tx.objectStore('b23_operations').get(key);","        const duplicate=tx.objectStore('b23_operations').get(key);globalThis.__phaseMark?.('operationQueued');");
patch('        duplicate.onsuccess=()=>{try{','        duplicate.onsuccess=()=>{globalThis.__phaseMark?.("operationReply");try{');
const instrumented=source.slice(0,begin)+part+source.slice(end);
const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let browser;
const report={evidence:'REAL_CHROME_IDB_REGISTER_PHASE_OFFSETS_NOT_EXCLUSIVE_CPU',acceptance:'NOT_ESTABLISHED',instrumentation:path,sourceHash:createHash('sha256').update(source).digest('hex')};
try{
 browser=await chromium.launch({headless:true,executablePath:process.env.FREE_CHROME_EXECUTABLE??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});report.browserVersion=browser.version();const context=await browser.newContext();await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();return u.pathname==='/'+path?route.fulfill({status:200,contentType:'text/javascript',body:instrumented}):route.continue();});
 const page=await context.newPage();await page.goto(origin+'/hf/A/c/T0?mode=native');report.result=await page.evaluate(async()=>{
  let phases=null,started=0;globalThis.__phaseMark=name=>{if(phases)phases[name]=performance.now()-started;};
  const [{ScopeRepository},{WorkspaceRepository},{emptyState},{digest}]=await Promise.all(['/src/b1/scope-repository.mjs','/src/data/repository.mjs','/src/data/state.mjs','/src/data/hash.mjs'].map(p=>import(p)));
  const scope={verified:true,provider:'chatgpt',accountId:'fixture',organizationId:'personal'},base=new ScopeRepository({indexedDB,databaseName:'shared-piece-count'}),repo=new WorkspaceRepository({baseRepository:base,evidenceGate:()=> 'synthetic'}),state=emptyState(scope);
  const id=i=>'60000000-0000-4000-8000-'+i.toString(16).padStart(12,'0'),ref=i=>({id:id(i),nativeUrl:'https://fixture.test/c/'+id(i),nativeTitle:'Synthetic title '+i,projectId:'P',available:true});state.revision=1;state.channel='synthetic';for(let i=0;i<3200;i++)state.refs[id(i)]=ref(i);
  try{
   if(!(await repo.initializePartitioned(scope,state)).ok)throw Error('seed-failed');if(!(await repo.migrateSharedDirectory(scope,{operationId:'count_migration',expectedRevision:1})).ok)throw Error('migration-failed');
   const db=await base.open(),normalized=base.scopeOrThrow(scope),runs=[];
   for(const existing of [false,true]){
    let result;phases={};started=performance.now();
    await new Promise((resolve,reject)=>{const tx=db.transaction(['b23_states','b23_checkpoints','b23_operations','refs'],'readwrite');let error;repo.registerNativeReferences(tx,normalized,Array.from({length:50},(_,i)=>({...ref((existing?0:3200)+i),availability:'available'})),existing?'phase_existing':'phase_new',()=>{},v=>{globalThis.__phaseMark('done');result=v;},e=>{error=e;tx.abort();},{preferDirectory:true,migrateLegacy:true});tx.oncomplete=()=>{globalThis.__phaseMark('txcomplete');resolve();};tx.onabort=()=>reject(error??tx.error);});
    const measured=phases;phases=null;if(result?.added!==(existing?0:50))throw Error('unexpected-added');
    runs.push({kind:existing?'existing50':'new50',added:result.added,offsets:measured,operationReads:Object.hasOwn(measured,'operationQueued')?1:0,operationWaitMs:measured.operationReply===undefined?null:measured.operationReply-measured.operationQueued,operationFractionOfRegisterToDone:measured.operationReply===undefined?null:(measured.operationReply-measured.operationQueued)/(measured.done-measured.register)});
   }
   const facts=(await repo.read(scope)).state;if(Object.keys(facts.refs).length!==3250)throw Error('incomplete-registration');return {runs,refs:3250};
  }finally{phases=null;base.close();}
 });
 assert.equal(report.result.runs.length,2);report.status='MEASURED';
}catch(error){report.status='FAIL';report.error=error.stack;process.exitCode=1;}finally{
 for(const close of [()=>browser?.close(),()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))])try{await close();}catch(e){report.cleanupError=String(e);process.exitCode=1;}
 assert.equal(await readFile(root+path,'utf8'),source);await writeFile('/private/tmp/shared-register-phase.json',JSON.stringify(report,null,2)+'\n');
}
console.log(JSON.stringify(report));
