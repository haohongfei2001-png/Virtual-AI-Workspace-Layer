from pathlib import Path
import re
root=Path.cwd();p=root/'tests/host/j2-package-journey.mjs';s=p.read_text()
s=re.sub(r"from (['\"])(\.[^'\"]+)\1",lambda m:'from '+repr((p.parent/m[2]).resolve().as_uri()),s)
s=s.replace("import {j2Within", "import {j2Within",1)
needle="const report={profile:selected.profile"
s=s.replace(needle,"""const diagnosticPath=join(built.unpacked,'src/host/content-session.mjs');
const originalDiagnosticSource=await readFile(diagnosticPath,'utf8');
const terminationAnchor='onTerminated:(reason,presentation)=>{';
if(originalDiagnosticSource.split(terminationAnchor).length!==2)throw Error('termination-diagnostic-anchor');
const diagnosticSource=originalDiagnosticSource.replace(terminationAnchor,terminationAnchor+`console.log('J2_TERMINATION_DIAGNOSTIC:'+JSON.stringify({reason,enabled,ready:s.ready,live:live(s),busyClose:s.busyClose===true,recoveryDenied:s.recoveryDenied===true,recoveryRemaining,rebindQueued,current:current===s}));`);
await (await import('node:fs/promises')).writeFile(diagnosticPath,diagnosticSource);
"""+needle)
s=s.replace("page.on('pageerror',e=>report.errors.push(e.message));", "page.on('pageerror',e=>report.errors.push(e.message));page.on('console',m=>{const text=m.text();if(text.startsWith('J2_TERMINATION_DIAGNOSTIC:'))(report.terminationDiagnostic??=[]).push(JSON.parse(text.slice('J2_TERMINATION_DIAGNOSTIC:'.length)));});")
s=s.replace("}console.log(JSON.stringify(report));","report.originalVerdict=report.status;report.status='DIAGNOSTIC_ONLY_TERMINATION';report.instrumentation={original:hash(originalDiagnosticSource),modified:hash(diagnosticSource)};await writeFile(output,JSON.stringify(report,null,2)+'\\n');}console.log(JSON.stringify({status:report.status,failedStage:report.failedStage,terminationDiagnostic:report.terminationDiagnostic}));")
Path('/private/tmp/free-j2-termination-diagnostic.mjs').write_text(s)
