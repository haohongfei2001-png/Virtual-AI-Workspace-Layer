from pathlib import Path
p=Path('/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/src/data/native-repository.mjs');s=p.read_text()
needle='  #rootWithCounts(row,scope)'
i=s.index(needle)
s=s[:i]+'''  #indexReader(row,scope,store,fail){
    let reader;
    const payload=this.#rootCache.read(row,this.#rootContext(row,scope),(_payload,record)=>{
      reader=createNativeIndexReader(store,unpack(record),scope,fail);
    });
    return reader??createNativeIndexReader(store,payload,scope,fail);
  }
'''+s[i:]
s=s.replace('''          const payload = counted?.payload ?? (request.result ? this.verifiedRoot(request.result, normalized) : emptyNativeFacts(normalized));''','''          const indexReader=request.result?.payload?.format===NATIVE_INDEX_FORMAT?this.#indexReader(request.result,normalized,store,fail):null;
          const payload = indexReader?.root ?? counted?.payload ?? (request.result ? this.verifiedRoot(request.result, normalized) : emptyNativeFacts(normalized));''')
s=s.replace('const reader=createNativeIndexReader(store,payload,normalized,fail),marker=', 'const reader=indexReader,marker=')
old='''          const payload = request.result ? this.verifiedRoot(request.result, normalized) : null;
          const indexReader=payload?.format===NATIVE_INDEX_FORMAT?createNativeIndexReader(states,payload,normalized,failure=>abort(failure.message)):null;'''
new='''          const indexReader=request.result?.payload?.format===NATIVE_INDEX_FORMAT?this.#indexReader(request.result,normalized,states,failure=>abort(failure.message)):null;
          const payload = indexReader?.root ?? (request.result ? this.verifiedRoot(request.result, normalized) : null);'''
assert old in s;s=s.replace(old,new)
Path('/private/tmp/free-native-reader-candidate.mjs').write_text(s)
