import {createServer} from 'node:http';
import {mkdtemp,readFile,writeFile,rm,cp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/b1/tooling/node_modules/playwright/index.mjs';
import {packageHost,verifyHost} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/extension/package.mjs';
import {launchNativeVisibilityBrowser} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/native-visibility-browser.mjs';
import {createHistoricalNetworkGuard} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/historical-network-guard.mjs';
import {observeFaultMetadataResponse} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/fault-metadata-response.mjs';
const bounded=async p=>{let t;try{return await Promise.race([p,new Promise((_,reject)=>t=setTimeout(()=>reject(Error('minimal-repro-deadline')),6000))]);}finally{clearTimeout(t);}};
const bytes=Buffer.from(JSON.stringify({protocol:'future-99',payload:{opaque:true}}));
const server=createServer((req,res)=>{if(!/^\/case\/[0-3]$/.test(req.url)){res.writeHead(404);res.end();return;}res.writeHead(200,{'content-type':'application/json','content-length':String(bytes.length),'cache-control':'no-store'});res.end(bytes);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const origin='http://127.0.0.1:'+server.address().port,dir=await mkdtemp(join(tmpdir(),'vaiwl-eof-abort-repro-'));
let guard,handle;const report={kind:'OFFLINE_MINIMAL_EOF_ABORT_MECHANISM_NOT_ACCEPTANCE',cases:[],realProfile:'NOT_RUN',sourceCommit:'fa86479ff4862fcb99f4744c3d7bb48b5a47ef87'};
try{
 guard=await createHistoricalNetworkGuard({fixtureOrigin:origin});
 const built=packageHost(join(dir,'package'),{offlineOrigin:origin}),manifest=JSON.parse(await readFile(join(built.unpacked,'build-manifest.json')));
 report.sourceHashes=manifest.sourceHashes;
 const probe=join(dir,'probe');await cp(built.unpacked,probe,{recursive:true});const workerPath=join(probe,'extension/classic-runtime.js'),originalWorker=await readFile(workerPath,'utf8');
 if(originalWorker.split('async function readSessionJSON(').length!==2||!originalWorker.endsWith('})();\n'))throw Error('reader-export-anchor');
 const probeWorker=originalWorker.slice(0,-6)+'globalThis.__offlineReadSessionJSON=readSessionJSON;\n})();\n';await writeFile(workerPath,probeWorker);report.testOnlyWorkerExport={path:'extension/classic-runtime.js',original:createHash('sha256').update(originalWorker).digest('hex'),instrumented:createHash('sha256').update(probeWorker).digest('hex'),productionCodeModified:false};
 handle=await launchNativeVisibilityBrowser({chromium,executablePath:process.env.EOF_REPRO_CFT==='1'?chromium.executablePath():'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',profileDir:join(dir,'profile'),headed:false,historicalNetworkGuard:guard.config});
 const {browser,context}=handle;report.browserVersion=browser.version();
 const cdp=await browser.newBrowserCDPSession(),{id}=await cdp.send('Extensions.loadUnpacked',{path:probe});
 const worker=context.serviceWorkers().find(w=>w.url().startsWith('chrome-extension://'+id+'/'))??await context.waitForEvent('serviceworker',{predicate:w=>w.url().startsWith('chrome-extension://'+id+'/'),timeout:15000});
 await bounded((async()=>{while(!await worker.evaluate(()=>typeof __offlineReadSessionJSON==='function'))await new Promise(r=>setTimeout(r,20));})());
 report.workerNetworkBlocked=await worker.evaluate(async()=>{try{await fetch('https://example.invalid/',{signal:AbortSignal.timeout(1500)});return false;}catch{return true;}});
 for(const [index,{abortAfterEOF,observeAfterEOF}] of [{abortAfterEOF:false,observeAfterEOF:false},{abortAfterEOF:true,observeAfterEOF:false},{abortAfterEOF:false,observeAfterEOF:true},{abortAfterEOF:true,observeAfterEOF:true}].entries()){
  const target=origin+'/case/'+index,row={index,abortAfterEOF,observeAfterEOF};report.cases.push(row);
  let response,observed;let resolveResponse;const ready=new Promise(r=>resolveResponse=r);
  const listener=r=>{if(r.url()!==target||r.request().serviceWorker()!==worker)return;response=r;row.status=r.status();if(!observeAfterEOF)observed=observeFaultMetadataResponse(r,row);resolveResponse();};context.on('response',listener);
  try{
   row.consumer=await bounded(worker.evaluate(async({target,abortAfterEOF})=>{
    const readSessionJSON=globalThis.__offlineReadSessionJSON;
    const c=new AbortController(),response=await fetch(target,{method:'GET',credentials:'include',cache:'no-store',redirect:'error',signal:c.signal,headers:{Accept:'application/json'}});
    let complete=false,protocol=false;
    try{const raw=await readSessionJSON(response,{target,limit:4096,raw:true,check:()=>{if(c.signal.aborted)throw Error('aborted');}});complete=true;protocol=JSON.parse(raw).protocol==='future-99';}
    finally{if(abortAfterEOF)c.abort();}
    return {actualReaderEOF:complete,expectedUnknown:protocol,signalAborted:c.signal.aborted};
   },{target,abortAfterEOF}));
   await bounded(ready);if(observeAfterEOF)observed=observeFaultMetadataResponse(response,row);await bounded(observed);
  }finally{context.off('response',listener);}
 }
 report.packageVerified=verifyHost(built.unpacked).status==='OFFLINE_HOST_RECONSTRUCTION';
 report.sourceUnchanged=(await Promise.all(Object.entries(report.sourceHashes).map(async([p,h])=>createHash('sha256').update(await readFile(p)).digest('hex')===h))).every(Boolean);
}catch(e){report.error=String(e?.stack??e);process.exitCode=1;}
finally{
 const clean=await Promise.allSettled([handle?.close(),guard?.close(),new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))]);report.cleanup=clean.map(x=>x.status);report.guard=guard?.snapshot();await rm(dir,{recursive:true,force:true});
 await writeFile('/private/tmp/vaiwl-ci39638853187/metadata-eof-abort-repro'+(process.env.EOF_REPRO_CFT==='1'?'-cft':'')+'.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({kind:report.kind,cases:report.cases,error:report.error,cleanup:report.cleanup,sourceUnchanged:report.sourceUnchanged}));
}
