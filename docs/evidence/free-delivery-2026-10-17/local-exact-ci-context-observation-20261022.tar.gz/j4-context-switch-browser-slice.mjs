import assert from 'node:assert/strict';
import {mkdtemp,readFile,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/b1/tooling/node_modules/playwright/index.mjs';
import {packageHost,verifyHost} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/extension/package.mjs';
import {launchNativeVisibilityBrowser} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/native-visibility-browser.mjs';
import {createHistoricalNetworkGuard} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/historical-network-guard.mjs';
import {createVariantHostFixtureServer} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/fixtures/variants-server.mjs';
import {installJ4GrantObserver} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/j4-grant-observer.mjs';
import {contextScope} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/j4-package-journey.mjs';
import {observeJ4ContextSwitch} from '/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer/tests/host/j4-context-switch-observer.mjs';
const hash=v=>createHash('sha256').update(v).digest('hex');
const dir=await mkdtemp(join(tmpdir(),'vaiwl-j4-native-switch-')),server=await createVariantHostFixtureServer({profile:'MODERN',journey:'J4',interruption:true});
const report={kind:'S_J4_NATIVE_CONTEXT_SWITCH_PREFIX_ONLY',sourceCommit:'fa86479ff4862fcb99f4744c3d7bb48b5a47ef87',fullJ4:'NOT_ESTABLISHED',realChatGPT:'NOT_RUN',actions:[]};let guard,handle,observation;
try{
 guard=await createHistoricalNetworkGuard({fixtureOrigin:server.origin});
 const built=packageHost(join(dir,'package'),{offlineOrigin:server.origin,offlineContext:true,offlineExistingSend:true,offlineHistory:true});
 report.sourceHashes=JSON.parse(await readFile(join(built.unpacked,'build-manifest.json'))).sourceHashes;
 report.runnerFixtureHashes=Object.fromEntries(await Promise.all(['tests/host/j4-context-switch-observer.mjs','tests/host/j4-package-journey.mjs','tests/host/fixtures/j4-native-context.mjs','tests/host/fixtures/variants-server.mjs','tests/host/j4-grant-observer.mjs'].map(async p=>[p,hash(await readFile(p))])));
 handle=await launchNativeVisibilityBrowser({chromium,executablePath:chromium.executablePath(),profileDir:join(dir,'profile'),headed:false,historicalNetworkGuard:guard.config});const {context,browser}=handle;report.browserVersion=browser.version();
 await context.route('**/*',r=>r.request().url().startsWith(server.origin+'/')||r.request().url().startsWith('chrome-extension://')?r.continue():r.abort());await context.addInitScript(installJ4GrantObserver);
 const cdp=await browser.newBrowserCDPSession(),{id}=await cdp.send('Extensions.loadUnpacked',{path:built.unpacked});
 const worker=context.serviceWorkers().find(w=>w.url().startsWith('chrome-extension://'+id+'/'))??await context.waitForEvent('serviceworker',{timeout:15000});
 assert(await worker.evaluate(async()=>{try{await fetch('https://example.invalid/',{signal:AbortSignal.timeout(1500)});return false;}catch{return true;}}));
 const frame=p=>p.frames().find(f=>f.url()==='chrome-extension://'+id+'/workspace.html'),key=s=>JSON.stringify([s.provider,s.accountId,s.organizationId]);
 async function mounted(p){const deadline=Date.now()+15000;while(!frame(p)){if(Date.now()>=deadline)throw Error('frame-deadline');await new Promise(r=>setTimeout(r,25));}const f=frame(p);await f.waitForFunction(()=>globalThis.j4LastScope,null,{timeout:Math.max(1,deadline-Date.now())});return f.evaluate(()=>j4LastScope);}
 const a=await context.newPage();await a.goto(server.origin+'/c/33333333-3333-4333-8333-333333333333');assert.equal(await mounted(a),key(contextScope('account-host-team')));
 const b=await context.newPage();await b.goto(server.origin+'/c/33333333-3333-4333-8333-333333333333');assert.equal(await mounted(b),key(contextScope('account-host-team')));
 observation=await observeJ4ContextSwitch(a,{origin:server.origin});
 await a.bringToFront();await a.locator('#account-button').click();const navigated=a.waitForNavigation();await a.locator('#native-dialog').getByRole('button',{name:'Switch to Personal',exact:true}).click();await navigated;
 assert.equal(await mounted(a),key(contextScope('account-host-personal')));assert.equal(await mounted(b),key(contextScope('account-host-team')));
 assert.equal(server.snapshot().actions['context-switch'],1);report.observation=await observation.finish(server.snapshot());
 assert.equal(report.observation.server.requests,1);assert.equal(report.observation.server.successfulSwitches,1);assert(report.observation.network.events.some(e=>e.type==='response'&&e.status===200));assert.equal(report.observation.network.dropped,0);
 report.actions=server.snapshot().actions;report.packageVerified=verifyHost(built.unpacked).status==='OFFLINE_HOST_RECONSTRUCTION';report.sourceUnchanged=(await Promise.all(Object.entries({...report.sourceHashes,...report.runnerFixtureHashes}).map(async([p,h])=>hash(await readFile(p))===h))).every(Boolean);assert(report.sourceUnchanged);report.status='PASS_PREFIX_ONLY_NOT_HISTORICAL_FAILURE_EXPLANATION';
}catch(e){report.status='FAIL';report.error=String(e?.stack??e);process.exitCode=1;}
finally{if(observation)report.observation=await observation.finish(server.snapshot());report.cleanup=(await Promise.allSettled([handle?.close(),server.close(),guard?.close()])).map(x=>x.status);report.guardClosed=guard?.snapshot().closed;await rm(dir,{recursive:true,force:true});await writeFile('/private/tmp/vaiwl-ci39638853187/j4-context-switch-browser-slice.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,observation:report.observation,error:report.error,cleanup:report.cleanup,guardClosed:report.guardClosed}));}
