// Fresh independent review of reconstructed ownership patch after cloud reset.
// Run with current checkout root as cwd; no checkout writes. Mutants stay in RAM.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const files=['src/navigation/navigation.mjs','tests/host/frame-projection-renderer.test.mjs','tests/navigation/current-dispatch.test.mjs','tests/host/working-set-pointer-race.test.mjs','tests/host/navigation-queued-background-intent.test.mjs','tests/navigation/visible-actions.test.mjs'];
const hashes=()=>Object.fromEntries(files.map(p=>[p,createHash('sha256').update(fs.readFileSync(p)).digest('hex')]));
const before=hashes(),startedAt=new Date().toISOString();
const base=new URL('./src/navigation/navigation.mjs',`file://${process.cwd()}/`);
const source=fs.readFileSync(base,'utf8').replace(/from '([^']+)'/g,(_,s)=>`from '${new URL(s,base).href}'`);
const harness=fs.readFileSync('tests/host/frame-projection-renderer.test.mjs','utf8').split("for(const boundary of ['same-scope-refresh'")[0];
const data=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
async function load(code){return import(data(harness.replace("'../../src/navigation/navigation.mjs'",JSON.stringify(data(code)))+'\nexport {fixture,projection};'));}
async function checks(code){const {fixture,projection}=await load(code),out=[];
 function run(name,body){try{body();out.push({name,status:'PASS'});}catch(e){out.push({name,status:'FAIL',message:e.message});}}
 for(const role of ['workspace','sidebar'])run('retired old disclosure in '+role,()=>{const calls=[],f=fixture(role,q=>{calls.push(q);return null;});try{f.nav.updateFrameProjection(projection(role));if(role==='sidebar')f.button('侧栏主题 Original P2').click();const old=f.button('展开旧窗口 Original P2');assert(old);f.nav.updateFrameProjection(projection(role));const count=calls.length;old.click();assert.equal(calls.length,count);assert.equal(f.nav.view().oldOpen.size,0);}finally{f.nav.stop();}});
 run('invalidate-remount same saved view cannot revive retired sidebar control',()=>{const calls=[],f=fixture('sidebar',q=>{calls.push(q);return null;});try{f.nav.updateFrameProjection(projection('sidebar'));const old=f.button('侧栏主题 Original P2');f.nav.invalidate();f.nav.updateFrameProjection(projection('sidebar'));old.click();assert.equal(calls.length,0);assert.equal(f.nav.view().sidebarOpen.size,0);f.button('侧栏主题 Original P2').click();assert.equal(calls.length,1);assert.deepEqual([...f.nav.view().sidebarOpen],['P2']);}finally{f.nav.stop();}});
 for(const role of ['workspace','sidebar'])run('held pointer preserves current '+role+' disclosure',()=>{const calls=[],timers=new Map();let next=0;const f=fixture(role,q=>{calls.push(q);return null;});f.doc.defaultView.setTimeout=fn=>{timers.set(++next,fn);return next};f.doc.defaultView.clearTimeout=id=>timers.delete(id);try{f.nav.updateFrameProjection(projection(role));const label=(role==='sidebar'?'侧栏主题 ':'展开旧窗口 ')+'Original P2',control=f.button(label),owner=f.nav.roots()[role].n;f.doc.handlers.get('pointerdown')({pointerId:1,composedPath:()=>[control,owner]});f.nav.updateFrameProjection(projection(role));assert.equal(f.button(label),control);f.doc.handlers.get('pointerup')({pointerId:1});control.click();assert.equal(calls.length,1);assert.equal(calls[0].groupId,'P2');}finally{f.nav.stop();}});
 return out;
}
assert(source.includes('if(isCurrent&&!isCurrent())return;'),'exact predicate mutation anchor required');
const results={current:await checks(source),removeCurrentPredicate:await checks(source.replace('if(isCurrent&&!isCurrent())return;','')),blockAllDisclosures:await checks(source.replace('if(isCurrent&&!isCurrent())return;','if(isCurrent)return;'))};
const after=hashes();
const unchanged=JSON.stringify(before)===JSON.stringify(after),reviewPass=results.current.every(r=>r.status==='PASS')&&results.removeCurrentPredicate.filter(r=>r.status==='FAIL').length===3&&results.blockAllDisclosures.filter(r=>r.status==='FAIL').length===4&&unchanged;
console.log(JSON.stringify({startedAt,finishedAt:new Date().toISOString(),cwd:process.cwd(),node:process.version,provenance:'Fresh reconstructed-candidate run. Historical reset-erased artifacts not recovered.',evidence:'Synthetic renderer callback ownership only; no actual browser scheduling or MV3 acceptance claim',reviewPass,sourceUnchangedDuringRun:unchanged,sourceHashesBefore:before,sourceHashesAfter:after,results},null,2));
if(!reviewPass)process.exitCode=1;
