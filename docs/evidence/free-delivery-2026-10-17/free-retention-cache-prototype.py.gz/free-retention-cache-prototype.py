from pathlib import Path
root=Path('/Users/hhf/Documents/GitHub/Virtual-AI-Workspace-Layer')
files=['verified-record-cache.mjs','partitioned.mjs','shared-directory-retention.mjs','repository.mjs']
def replace(s,a,b,count=1):
 assert s.count(a)==count,(a,s.count(a));return s.replace(a,b)
for f in files:
 s=(root/'src/data'/f).read_text()
 if f=='verified-record-cache.mjs':
  s=replace(s,'read(row,context,verify){return this.#read(row,context,verify);}','read(row,context,verify){return this.#read(row,context,verify);}\n readHistorical(row,context,verify){return this.#read(row,context,verify,null,null,true);}')
  s=replace(s,'#read(row,context,verify,fields=null,counts=null){','#read(row,context,verify,fields=null,counts=null,historical=false){')
  s=replace(s,'this.#entries.delete(key);this.#entries.set(key,prior);return row.payload;','if(!historical){this.#entries.delete(key);this.#entries.set(key,prior);}return row.payload;')
  s=replace(s,'this.#entries.set(key,{encoded,checksum:row.checksum});this.#chars+=encoded.length;','if(historical)this.#entries=new Map([[key,{encoded,checksum:row.checksum}],...this.#entries]);else this.#entries.set(key,{encoded,checksum:row.checksum});this.#chars+=encoded.length;')
 if f=='partitioned.mjs':
  s=replace(s,'verifiedDirectory(row,scope){','verifiedDirectory(row,scope,historical=false){')
  s=replace(s,'return this.#directoryCache.read(row,scope.key,','const revision=Object.getOwnPropertyDescriptor(row?.payload??{},\'revision\')?.value;const context=JSON.stringify([scope.key,Number.isSafeInteger(revision)&&revision>0?revision:null]);return this.#directoryCache[historical?\'readHistorical\':\'read\'](row,context,')
 if f=='shared-directory-retention.mjs':
  s=replace(s,'prepareSharedDirectoryRetention(tx,scope,prior,check,fail){','prepareSharedDirectoryRetention(tx,scope,prior,check,fail,verify=null){')
  s=replace(s,'const candidate=manifest_partitionUnpack(row);validateSharedDirectoryRoot(candidate,scope);old=candidate;','const candidate=verify?verify(row):manifest_partitionUnpack(row);validateSharedDirectoryRoot(candidate,scope);old=candidate;')
 if f=='repository.mjs':
  s=replace(s,'e=>abort(e.message)):null;','e=>abort(e.message),row=>this.partitioned.verifiedDirectory(row,s,true)):null;')
  s=replace(s,'storage.manifest,check,fail):null;','storage.manifest,check,fail,row=>this.partitioned.verifiedDirectory(row,s,true)):null;')
 Path('/private/tmp/free-retention-'+f).write_text(s)
s=Path('/private/tmp/free-native-reader-idb-ab.mjs').read_text()
a=s.index('const baseline=');b=s.index('const sourceHashes=',a)
s=s[:a]+"const variants={};for(const name of "+repr(files)+"){const path='/src/data/'+name;variants[path]={baseline:await readFile(root+path.slice(1),'utf8'),candidate:await readFile('/private/tmp/free-retention-'+name,'utf8')};}\n"+s[b:]
s=s.replace("baselineHash:hash(baseline),candidateHash:hash(candidate)","variantHashes:Object.fromEntries(Object.entries(variants).map(([p,v])=>[p,{baseline:hash(v.baseline),candidate:hash(v.candidate)}]))")
s=s.replace("if(u.pathname==='/src/data/native-repository.mjs')return route.fulfill({status:200,contentType:'text/javascript',body:variant==='candidate'?candidate:baseline});","if(variants[u.pathname])return route.fulfill({status:200,contentType:'text/javascript',body:variants[u.pathname][variant]});")
s=s.replace("assert.equal(hash(await readFile('/private/tmp/free-native-reader-candidate.mjs')),hash(candidate));","")
s=s.replace('DIAGNOSTIC_REAL_IDB_NATIVE_READER_OWNER_PAGE_APPLY_AB','DIAGNOSTIC_REAL_IDB_RETENTION_EXISTING_CACHE_AB').replace('/private/tmp/free-native-reader-idb-ab.json','/private/tmp/free-retention-cache-idb-ab.json')
Path('/private/tmp/free-retention-cache-idb-ab.mjs').write_text(s)
