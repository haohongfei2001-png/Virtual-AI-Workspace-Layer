import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createSurfaceDiscovery,LEGACY_SURFACE_PROFILE as profile} from '../../src/host/surface-discovery.mjs';
import {createURLPolicy} from '../../src/host/url-policy.mjs';

// L-only DOM double: computed visibility inherits from ancestors, including the
// authenticated owned mask root. No claim of actual browser CSS isolation.
function fixture({masked=true,owned=true}={}){
 const doc={location:{href:'https://chatgpt.com/g/p1/project'}};
 function node(tag='DIV',text='',attrs={},parent=null){
  const n={tagName:tag,textContent:text,attrs,parentNode:parent,parentElement:parent,ownerDocument:doc,isConnected:true,children:[],style:{},hidden:false,
   getAttribute(k){return attrs[k]??null;},hasAttribute(k){return Object.hasOwn(attrs,k);},getClientRects(){return [{}];},
   contains(other){for(let p=other;p;p=p.parentElement)if(p===n)return true;return false;},
   matches(s){return s==='a[href]'?tag==='A'&&attrs.href!==undefined:s==='a[href],button'&&(tag==='BUTTON'||tag==='A'&&attrs.href!==undefined);}
  };if(parent)parent.children.push(n);return n;
 }
 const body=node('BODY'),main=node('MAIN','',{},body),header=node('HEADER','',{},main),h1=node('H1','Native project',{},header),reading=node('SECTION','',{},main),heading=node('H2','Native project',{},reading),members=node('NAV','',{'data-project-id':'p1'},reading),wrapper=node('DIV','',{},members),link=node('A','Fresh member',{href:'/c/c1'},wrapper),projects=node('SECTION','',{},body),history=node('NAV','',{},body);
 const map=new Map([[profile.regions.projects,[projects]],[profile.regions.history,[history]],[profile.regions.members,[members]],[profile.currentProjectTitle,[heading]],[profile.currentProjectHeader,[h1]]]);doc.querySelectorAll=s=>map.get(s)??[];
 function computed(n){let visibility;for(let p=n;p;p=p.parentElement){if(masked&&p===reading){visibility='hidden';break;}if(p.style.visibility){visibility=p.style.visibility;break;}}return {display:n.style.display??'block',visibility:visibility??'visible'};}
 doc.defaultView={crypto:{randomUUID},getComputedStyle:computed};
 doc.createTreeWalker=root=>{const all=[];function visit(n){for(const c of n.children){all.push(c);visit(c);}}visit(root);let i=0;return {nextNode:()=>all[i++]??null};};
 const discovery=createSurfaceDiscovery({document:doc,binding:{documentToken:'doc',routeEpoch:1},profile,urlPolicy:createURLPolicy({profile:{projectId:({container})=>container,conversationId:id=>id}}),isOwnedMask:n=>owned&&masked&&n===reading});
 return {doc,discovery,reading,heading,members,wrapper,link,main,computed};
}
function scan(f){let cursor=null;const candidates=[],claims=[];for(let i=0;i<10;i++){const p=f.discovery.scanPage(cursor);candidates.push(...p.payload.candidates);claims.push(...p.payload.membershipClaims);cursor=p.cursor;if(!cursor)return {candidates,claims};}assert.fail('bounded fixture must terminate');}
function projectClaims(result){return result.claims.filter(c=>c.asserted==='PROJECT');}
function currentProject(result){return result.candidates.filter(c=>c.entity==='project'&&c.evidence.fieldPaths.includes('current-project-route'));}
test('visible baseline has current Project and explicit member proof',()=>{
 const f=fixture({masked:false});try{const r=scan(f);assert.equal(currentProject(r).length,1);assert.deepEqual(projectClaims(r).map(c=>[c.conversationId,c.projectId]),[['c1','p1']]);}finally{f.discovery.stop();}
});
test('owned root inherited hidden preserves current Project and descendant member proof',()=>{
 const f=fixture();try{
  for(const n of [f.reading,f.heading,f.members,f.wrapper,f.link])assert.equal(f.computed(n).visibility,'hidden');
  assert.equal(f.link.style.visibility,undefined,'child has no native visibility declaration');
  const r=scan(f);assert.equal(currentProject(r).length,1);assert.deepEqual(projectClaims(r).map(c=>[c.conversationId,c.projectId]),[['c1','p1']]);
  assert.equal(r.candidates.find(c=>c.entity==='conversation').nativeTitle,'Fresh member');
 }finally{f.discovery.stop();}
});
test('identical inherited hidden without authenticated owned root remains unconfirmed',()=>{
 const f=fixture({owned:false});try{const r=scan(f);assert.equal(currentProject(r).length,0);assert.deepEqual(projectClaims(r),[]);}finally{f.discovery.stop();}
});
const concealments={hidden:n=>n.hidden=true,'aria-hidden':n=>n.attrs['aria-hidden']='true','display-none':n=>n.style.display='none','visibility-collapse':n=>n.style.visibility='collapse','visibility-hidden':n=>n.style.visibility='hidden'};
for(const [kind,conceal]of Object.entries(concealments))for(const where of ['link','wrapper'])test(`native ${kind} on ${where} cannot borrow owned-root visibility`,()=>{
 const f=fixture();try{conceal(f[where]);const r=scan(f);assert.deepEqual(projectClaims(r),[],'native concealment cannot become PROJECT');}finally{f.discovery.stop();}
});
for(const kind of ['hidden','aria-hidden','display-none','visibility-collapse','visibility-hidden'])test('native ancestor above owned root '+kind+' prevents Project proof',()=>{
 const f=fixture();try{concealments[kind](f.main);const r=scan(f);assert.equal(currentProject(r).length,0);assert.deepEqual(projectClaims(r),[]);}finally{f.discovery.stop();}
});
